create database meuble;
\c meuble;

create table categorie(
    idCategorie serial primary key,
    nom varchar(30)
);

create table style (
    idStyle serial primary key,
    nom varchar(30)
);

create table volume(
    idVolume serial primary key,
    types varchar(20)
);

create table matiere(
    idMatiere serial primary key,
    nom varchar(30),
    prix double precision
);

create table meuble (
    idMeuble serial primary key,
    nom varchar(50),
    idCategorie int not null,
    idStyle int not null,
    idVolume int not null,
    foreign key(idCategorie) references categorie(idCategorie),
    foreign key(idStyle) references style(idStyle),
    foreign key(idVolume) references volume(idVolume)
);

create table prix_vente (
    idPrixVente serial primary key,
    idMeuble int not null,
    prix double precision,
    foreign key(idMeuble) references meuble(idMeuble)
);

create table matiere_style(
    idMS serial primary key,
    idStyle int not null,
    idMatiere int not null,
    foreign key(idStyle) references style(idStyle),
    foreign key(idMatiere) references matiere(idMatiere)
);

create table fabrication (
    idFabrication serial primary key,
    idMeuble int not null,
    idMS int not null,
    quantite int not null,
    foreign key(idMeuble) references meuble(idMeuble),
    foreign key(idMS) references matiere_style(idMS)
);

create table stockMatiere (
    idStockMatiere serial primary key,
    date date,
    idMatiere int not null,
    quantite int not null,
    foreign key(idMatiere) references matiere(idMatiere)
);

create table historiquefabricationMeuble (
    idFabricationMeuble serial primary key,
    date date,
    idMeuble int not null,
    quantite int not null
);

create table Poste (
    idPoste serial primary key,
    nom varchar(50),
    salaire double precision
);

create table NombrePosteFabrication(
    idNbPosteFabrication serial primary key,
    idMeuble int not null,
    nbOuvrier int not null,
    heure_travail int,
    foreign key(idMeuble) references Meuble(idMeuble)
);

create table PosteFabrication (
    idPosteFabrication serial primary key,
    idPoste int not null,
    idMeuble int not null,
    quantite int not null,
    foreign key(idPoste) references Poste(idPoste),
    foreign key(idMeuble) references Meuble(idMeuble)
);

create table Employe (
    idEmploye serial primary key,
    nom varchar(50),
    prenom varchar(50),
    datenaissance date
);

create table Profil (
    idProfil serial primary key,
    annee_min int,
    annee_max int,
    profil varchar(50)
);

create table RecrutementEmploye (
    idRecrutementEmploye serial primary key,
    date_recrutement date,
    idEmploye int not null,
    idPoste int not null,
    foreign key(idEmploye) references Employe(idEmploye),
    foreign key(idPoste) references Poste(idPoste)
);

create table genre (
    idGenre serial primary key,
    genre varchar(30)
);

create table client (
    idClient serial primary key,
    nom varchar(50),
    prenom varchar(50),
    idGenre int not null,
    foreign key(idgenre) references genre(idGenre)
);

create table vente (
    idvente serial primary key,
    date_vente date,
    idClient int not null,
    idMeuble int not null,
    quantite int not null,
    foreign key(idClient) references client(idClient),
    foreign key(idMeuble) references Meuble(idMeuble)
);


---------------------------------------------------------------------------

create table facture (
    idFacture serial primary key,
    dateFacture date,
    idClient int not null,
    ref varchar(50),
    foreign key(idClient) references client(idClient)
);

create table detailfacture (
    idDetailFacture serial primary key,
    idFacture int not null,
    idMeuble int not null,
    quantite int not null,
    foreign key(idFacture) references facture(idFacture),
    foreign key(idMeuble) references meuble(idMeuble)
);

create table payementfacture (
    idPayementFacture serial primary key,
    idFacture int not null,
    montant double precision,
    foreign key(idFacture) serial primary key
);

-----------------------------------------------------------------------------


insert into categorie(nom)values('chaise');
insert into categorie(nom)values('table');


insert into style(nom)values('royale');
insert into style(nom)values('scandinave');


insert into matiere(nom,prix)values('bois',3000);
insert into matiere(nom,prix)values('tissus',4000);
insert into matiere(nom,prix)values('plastique',5000);


insert into volume(types)values('petit');
insert into volume(types)values('moyen');
insert into volume(types)values('grand');


insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Chaise royale petite',1,1,1);
insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Chaise royale moyenne',1,1,2);
insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Chaise royale grande',1,1,3);
insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Table royale petite',2,1,1);
insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Table royale moyenne',2,1,2);
insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Table royale grande',2,1,3);

insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Chaise scandinave petite',1,2,1);
insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Chaise scandinave moyenne',1,2,2);
insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Chaise scandinave grande',1,2,3);
insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Table scandinave petite',2,2,1);
insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Table scandinave moyenne',2,2,2);
insert into meuble(nom,idCategorie,idStyle,idVolume) values ('Table scandinave grande',2,2,3);

insert into prix_vente (idMeuble,prix) values (1,75000);
insert into prix_vente (idMeuble,prix) values (2,110000);
insert into prix_vente (idMeuble,prix) values (3,120000);
insert into prix_vente (idMeuble,prix) values (4,150000);
insert into prix_vente (idMeuble,prix) values (5,150000);
insert into prix_vente (idMeuble,prix) values (6,150000);
insert into prix_vente (idMeuble,prix) values (7,150000);
insert into prix_vente (idMeuble,prix) values (8,150000);
insert into prix_vente (idMeuble,prix) values (9,150000);
insert into prix_vente (idMeuble,prix) values (10,150000);
insert into prix_vente (idMeuble,prix) values (11,150000);
insert into prix_vente (idMeuble,prix) values (12,150000);


insert into matiere_style(idStyle,idMatiere)values(1,1);
insert into matiere_style(idStyle,idMatiere)values(1,2);
insert into matiere_style(idStyle,idMatiere)values(2,2);


insert into fabrication(idMeuble,idMS,quantite) values (1,1,4);
insert into fabrication(idMeuble,idMS,quantite) values (1,2,5);
insert into fabrication(idMeuble,idMS,quantite) values (2,1,6);
insert into fabrication(idMeuble,idMS,quantite) values (2,2,7);

insert into stockMatiere(date,idMatiere,quantite) values (CURRENT_DATE,1,20);
insert into stockMatiere(date,idMatiere,quantite) values (CURRENT_DATE,2,20);

insert into Poste(nom,salaire) values ('MENUSIER',10000);
insert into Poste(nom,salaire) values ('SCULPTEUR',12000);
insert into Poste(nom,salaire) values ('TAPISSIER',13000);

insert into NombrePosteFabrication(idMeuble,nbOuvrier,heure_travail) values (1,2,1);
insert into NombrePosteFabrication(idMeuble,nbOuvrier,heure_travail) values (2,4,2);
insert into NombrePosteFabrication(idMeuble,nbOuvrier,heure_travail) values (3,8,4);

insert into PosteFabrication(idPoste,idMeuble,quantite) values (1,1,1);
insert into PosteFabrication(idPoste,idMeuble,quantite) values (2,1,1);
insert into PosteFabrication(idPoste,idMeuble,quantite) values (1,2,2);
insert into PosteFabrication(idPoste,idMeuble,quantite) values (2,2,2);
insert into PosteFabrication(idPoste,idMeuble,quantite) values (1,3,4);
insert into PosteFabrication(idPoste,idMeuble,quantite) values (2,3,4);


insert into Employe (nom,prenom,datenaissance) values ('RASAMISOA','Mahefa','2004-01-01');
insert into Employe (nom,prenom,datenaissance) values ('RASAMISOA','Mihanta','1999-12-06');
insert into Employe (nom,prenom,datenaissance) values ('RASAMISOA','Natanaela','1963-07-23');
insert into Employe (nom,prenom,datenaissance) values ('RASAMISOA','Vero','1963-07-03');


insert into Profil (profil,annee_min,annee_max) values ('ouvrier',0,1);
insert into Profil (profil,annee_min,annee_max) values ('senior',2,4);
insert into Profil (profil,annee_min,annee_max) values ('expert',5,999);

insert into RecrutementEmploye (date_recrutement,idEmploye,idPoste) values ('2024-01-21',1,1);
insert into RecrutementEmploye (date_recrutement,idEmploye,idPoste) values ('2024-01-21',2,1);
insert into RecrutementEmploye (date_recrutement,idEmploye,idPoste) values ('2021-01-21',3,2);
insert into RecrutementEmploye (date_recrutement,idEmploye,idPoste) values ('2019-01-21',4,3);

insert into genre (genre) values ('HOMME');
insert into genre (genre) values ('FEMME');

insert into client (nom,prenom,idGenre) values ('RASOLOMANANA','Kaliana',2);
insert into client (nom,prenom,idGenre) values ('RABOANARY','Miary',2);
insert into client (nom,prenom,idGenre) values ('RASOLOMANANA','Kintana',1);
insert into client (nom,prenom,idGenre) values ('RABOANARY','Ando',1);
insert into client (nom,prenom,idGenre) values ('RABOANARY','Aina',1);

insert into vente (date_vente,idClient,idMeuble,quantite) values ('2024-01-10',1,1,2);
insert into vente (date_vente,idClient,idMeuble,quantite) values ('2024-01-10',1,2,3);

insert into vente (date_vente,idClient,idMeuble,quantite) values ('2024-01-10',2,2,3);

insert into vente (date_vente,idClient,idMeuble,quantite) values ('2024-01-10',3,1,1);
insert into vente (date_vente,idClient,idMeuble,quantite) values ('2024-01-10',3,2,4);

insert into vente (date_vente,idClient,idMeuble,quantite) values ('2024-01-10',4,1,4);
insert into vente (date_vente,idClient,idMeuble,quantite) values ('2024-01-10',4,2,4);

insert into vente (date_vente,idClient,idMeuble,quantite) values ('2024-01-10',5,1,3);



select meuble.nom as meuble,volume.types as volume,style.nom as style,fabrication.quantite as quantite,fabrication.quantite*matiere.prix as prix from fabrication 
join matiere_style on matiere_style.idMS=fabrication.idMS 
join style on matiere_style.idStyle=style.idStyle 
join meuble on meuble.idMeuble=fabrication.idMeuble 
join matiere on matiere_style.idMatiere=matiere.idMatiere 
join volume on volume.idVolume=meuble.idVolume 



create or replace view v_fabrication as
select meuble.idmeuble as idmeuble,meuble.nom as meuble,volume.types as volume,style.nom as style,fabrication.quantite as quantite,fabrication.quantite*matiere.prix as prix from fabrication 
join matiere_style on matiere_style.idMS=fabrication.idMS 
join style on matiere_style.idStyle=style.idStyle 
join meuble on meuble.idMeuble=fabrication.idMeuble 
join matiere on matiere_style.idMatiere=matiere.idMatiere 
join volume on volume.idVolume=meuble.idVolume 


-- view pour avoir le prix total de fabrication par meuble
create or replace view v_sum_prix as
select idmeuble,meuble,sum(prix) as prix from v_fabrication group by idmeuble,meuble;


-- view pour avoir le salaire de chaque poste pour chaque meuble fabriquer
create or replace view v_salaire_poste as
select postefabrication.*,sum(quantite*salaire) as salaire_poste from postefabrication 
join poste on poste.idposte=postefabrication.idposte 
group by postefabrication.idpostefabrication;


-- view pour avoir le prix de revient de chaque meuble 
create or replace view v_prix_revient as
SELECT
    m.idmeuble,
    m.meuble,
    m.prix + COALESCE(SUM(sp.salaire_poste), 0) AS prix_total
FROM
    v_sum_prix m
LEFT JOIN
    v_salaire_poste sp ON m.idmeuble = sp.idmeuble
GROUP BY
    m.idmeuble, m.meuble, m.prix;


-- view pour avoir le benefice pour chaque meuble
create or replace view v_benefice as
select v_prix_revient.idmeuble,v_prix_revient.meuble,v_prix_revient.prix_total,min(prix_vente.prix-v_prix_revient.prix_total) as benefice 
from v_prix_revient 
join prix_vente on prix_vente.idmeuble=v_prix_revient.idmeuble group by v_prix_revient.idmeuble,v_prix_revient.meuble,v_prix_revient.prix_total; 


SELECT idrecrutementemploye, date_recrutement, employe.nom as nom, employe.prenom as prenom, poste.nom as poste, profil.profil,
    EXTRACT(YEAR FROM AGE(current_date, date_recrutement)) AS annee_travail
FROM RecrutementEmploye
JOIN employe ON employe.idEmploye=RecrutementEmploye.idEmploye 
JOIN poste ON poste.idposte=RecrutementEmploye.idposte 
JOIN profil ON profil.idProfil=RecrutementEmploye.idProfil

-- view pour afficher le taux horaire  d'un employé
create or replace view v_taux_horaire as
SELECT
    re.idrecrutementemploye,
    re.date_recrutement,
    e.nom,
    e.prenom,
    p.nom AS poste,
    pr.profil,
    CASE
        WHEN pr.profil = 'ouvrier' THEN p.salaire
        WHEN pr.profil = 'senior' THEN p.salaire * 2
        WHEN pr.profil = 'expert' THEN p.salaire * 3
    END AS taux_horaire
FROM
    recrutementemploye re
JOIN
    employe e ON e.idemploye=re.idemploye
JOIN
    poste p ON re.idposte = p.idposte
JOIN
    profil pr ON (EXTRACT(YEAR FROM AGE(CURRENT_DATE, re.date_recrutement)) BETWEEN pr.annee_min AND pr.annee_max);


-- view pour avoir les statistiques de ventes des meubles par genre
create or replace view v_stat as 
SELECT
    v.idmeuble,
    m.nom,
    COUNT(DISTINCT CASE WHEN c.idgenre = 1 THEN c.idclient END) AS nombre_hommes,
    COUNT(DISTINCT CASE WHEN c.idgenre = 2 THEN c.idclient END) AS nombre_femmes
FROM
    vente v
JOIN
    meuble m ON m.idmeuble=v.idmeuble
JOIN
    client c ON v.idclient = c.idclient
JOIN 
    genre g ON g.idgenre=c.idgenre
GROUP BY
    v.idmeuble,m.nom;


--view pour avoir le nombre total de meuble fabrique
create or replace view v_meuble_fabrique as 
select historiquefabricationmeuble.idmeuble,meuble.nom,sum(historiquefabricationmeuble.quantite) from historiquefabricationmeuble 
join meuble on meuble.idmeuble=historiquefabricationmeuble.idmeuble 
group by historiquefabricationmeuble.idmeuble,meuble.nom;
    

create or replace view v_meuble_restant as
SELECT
    vmf.idmeuble,
    vmf.nom,
    vmf.sum - COALESCE(v.total_vente, 0) AS quantite
FROM
    v_meuble_fabrique vmf
LEFT JOIN (
    SELECT
        idmeuble,
        SUM(quantite) AS total_vente
    FROM
        vente
    GROUP BY
        idmeuble
) v ON vmf.idmeuble = v.idmeuble;


