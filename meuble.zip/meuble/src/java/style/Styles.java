/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package style;
import connection.*;

import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author itu
 */
public class Styles {
    int idStyle;
    String nom;

    public Styles() {

    }

    public Styles(String nom) {
        this.setnom(nom);
    }

    public Styles(int idStyle,String nom) {
        this.setidStyle(idStyle);
        this.setnom(nom);
    }

    public static ArrayList<Styles> getMaterielByStyle(Connection connect,String style)throws Exception{
        ArrayList<Styles> list_style = new ArrayList<Styles>();
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select * from style";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Styles stl = new Styles(rs.getInt(1),rs.getString(2));
            list_style.add(stl);
        }
        
        rs.close();
        st.close();
        connect.close(); 

        return list_style;
    }

    public ArrayList<Styles> getAllStyle(Connection connect) throws Exception {
        ArrayList<Styles> list_style = new ArrayList<Styles>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select * from style";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Styles style = new Styles(rs.getInt("idstyle"),rs.getString("nom"));
            list_style.add(style);
        }
        rs.close();
        st.close();
        connect.close();

        return list_style;
    }

    public void insertStyle(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into style(nom) values('"+this.getnom()+"')";
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getidStyle(){
        return idStyle; 
    }
    public void setidStyle(int newidStyle){
        idStyle=newidStyle;
    } 
    public String getnom(){
        return nom; 
    }
    public void setnom(String newnom){
        nom=newnom;
    } 
}
