/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package connection;
import java.sql.*;

/**
 *
 * @author itu
 */
public class MyConnection {
    static String url="jdbc:postgresql://localhost:5432/meuble";
    static String user="postgres";
    static String mdp="Mahefa01";
    public static Connection connexion(String type)throws SQLException, Exception{
        if(type.equals("postgres")){
            try{
                Connection connection = null;
                Class.forName("org.postgresql.Driver");
                connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/meuble", "postgres", "Mahefa01");
                return connection;
            }
            catch(Exception e){
                throw new Exception(e.getMessage());
            }
        }
        throw new Exception("database inconnu");
    }
}
