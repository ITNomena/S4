package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import poste.Poste;
import employe.Employe;
import employe.Profil;
import employe.RecrutementEmploye;
import employe.*;

// import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "RecrutementServlet", value = "/RecrutementServlet")
public class RecrutementServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getRequestDispatcher("ajout_matierePremiere.jsp").forward(request, response);
        try {
            Employe employe = new Employe();
            ArrayList<Employe> list_employe = employe.getAllEmploye(null);

            Poste poste = new Poste();
            ArrayList<Poste> list_poste = poste.getAllPoste(null);

            RecrutementEmploye recrutementEmploye = new RecrutementEmploye();
            ArrayList<RecrutementEmploye> list_RecrutementEmployes = recrutementEmploye.getAllRecrutement(null);

            request.setAttribute("listEmploye",list_employe);
            request.setAttribute("listPoste",list_poste);
            request.setAttribute("listRecrutementEmploye",list_RecrutementEmployes);

        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Recrutement.jsp");
        dispat.forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String date = request.getParameter("date");
            String employe = request.getParameter("employe");
            String poste = request.getParameter("poste");        

            Employe emp = new Employe();
            emp.setIdEmploye(Integer.parseInt(employe));

            Poste p = new Poste();
            p.setIdPoste(Integer.parseInt(poste));


            RecrutementEmploye rct = new RecrutementEmploye(date,emp,p);
            rct.insertRecrutementEmploye(null);

        }catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        response.sendRedirect("RecrutementServlet");
    }
}