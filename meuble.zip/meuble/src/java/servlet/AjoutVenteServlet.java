package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
// import matiere.Matiere;
import employe.Employe;
import client.*;
import genre.*;
import meuble.*;
// import jakarta.servlet.annotation.*;
import poste.*;
import vente.Vente;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AjoutVenteServlet", value = "/AjoutVenteServlet")
public class AjoutVenteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getRequestDispatcher("ajout_matierePremiere.jsp").forward(request, response);
        try {
            String erreur = request.getParameter("erreur");

            Vente vente = new Vente();
            ArrayList<Vente> list_vente = vente.getAllVente(null);

            Meuble meuble = new Meuble();
            ArrayList<Meuble> list_meuble = meuble.getAllMeuble(null);

            Client client = new Client();
            ArrayList<Client> liste_client = client.getAllClient(null);
            
            Genre genre = new Genre();
            ArrayList<Genre> list_genre = genre.getAllGenre(null);

            if (erreur!=null && !erreur.isEmpty()) {
                request.setAttribute("erreur",erreur);
            }

            request.setAttribute("listVente",list_vente);
            request.setAttribute("listMeuble",list_meuble);
            request.setAttribute("listGenre",list_genre);
            request.setAttribute("listClient",liste_client);

        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Form_Vente.jsp");
        dispat.forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String dateVente = request.getParameter("dateVente");
            String idClient = request.getParameter("client");        
            String idMeuble = request.getParameter("meuble");
            String quantite = request.getParameter("quantite");

            Vente v = new Vente().getMeubleRestantByIdMeuble(null, Integer.parseInt(idClient),Integer.parseInt(quantite));
            
            Client cl=new Client();
            cl.setIdClient(Integer.parseInt(idClient));
            
            Meuble mb=new Meuble();
            mb.setIdMeuble(Integer.parseInt(idMeuble));

            Vente vt = new Vente(dateVente,cl,mb,Integer.parseInt(quantite));

            vt.insertVente(null);

            response.sendRedirect("AjoutVenteServlet");
            
        }catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
            response.sendRedirect("AjoutVenteServlet?erreur="+e.getMessage());
            // e.printStackTrace();
            // System.out.println(e.getMessage());
        }
    }
}