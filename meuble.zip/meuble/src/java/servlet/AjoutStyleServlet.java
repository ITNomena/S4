package servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import style.Styles;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AjoutStyleServlet", value = "/AjoutStyleServlet")
public class AjoutStyleServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Styles style = new Styles();
            ArrayList<Styles> list_style = style.getAllStyle(null);

            request.setAttribute("listStyle",list_style);
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Form_Style.jsp");
        dispat.forward(request,response); 
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String style = request.getParameter("style");
        Styles stl = new Styles(style);

        try {
            stl.insertStyle(null);
        }catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        request.getRequestDispatcher("Form_Matiere.jsp").forward(request, response);
    }
}
