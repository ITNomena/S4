package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import matiere.Matiere;
import meuble.Meuble;
// import jakarta.servlet.annotation.*;
import poste.*;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AjoutPosteServlet", value = "/AjoutPosteServlet")
public class AjoutPosteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getRequestDispatcher("ajout_matierePremiere.jsp").forward(request, response);
        try {
            Poste poste = new Poste();
            ArrayList<Poste> list_poste = poste.getAllPoste(null);

            request.setAttribute("listPoste",list_poste);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Form_Poste.jsp");
        dispat.forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String poste = request.getParameter("poste");        
            String salaire = request.getParameter("salaire");

            Poste pst = new Poste(poste,Double.parseDouble(salaire));
            pst.insertPoste(null);
        }catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        response.sendRedirect("AjoutPosteServlet");
    }
}