package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import client.*;
import genre.*;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AjoutClientServlet", value = "/AjoutClientServlet")
public class AjoutClientServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getRequestDispatcher("ajout_matierePremiere.jsp").forward(request, response);
        try {
            Genre genre = new Genre();
            ArrayList<Genre> list_genre = genre.getAllGenre(null);

            Client cl = new Client();
            ArrayList<Client> list_client = cl.getAllClient(null);

            request.setAttribute("listGenre",list_genre);
            request.setAttribute("listClient",list_client);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Form_Client.jsp");
        dispat.forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String nom = request.getParameter("nom");        
            String prenom = request.getParameter("prenom");
            String genre = request.getParameter("genre");

            Genre g = new Genre();
            g.setIdGenre(Integer.parseInt(genre));

            Client cl = new Client(nom,prenom,g);
            cl.insertClient(null);
            
        }catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        response.sendRedirect("AjoutClientServlet");
    }
}