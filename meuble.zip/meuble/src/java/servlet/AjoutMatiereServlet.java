package servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import matiere.Matiere;
import style.Styles;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AjoutMatiereServlet", value = "/AjoutMatiereServlet")
public class AjoutMatiereServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Matiere matiere = new Matiere();
            ArrayList<Matiere> list_matiere = matiere.getAllMatiere(null);

            request.setAttribute("listMatiere",list_matiere);            
            
        } catch (Exception e) {
            e.printStackTrace();
            // System.out.println(e.getMessage());
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Form_Matiere.jsp");
        dispat.forward(request,response); 
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String prix = request.getParameter("prix");        
            String matiere = request.getParameter("matiere");

            Matiere mtr = new Matiere(matiere,Double.parseDouble(prix));
            mtr.insertMatiere(null);
        }catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        request.getRequestDispatcher("/AjoutMatiereStyleServlet").forward(request, response);
    }
}
