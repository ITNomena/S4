package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import matiere.Matiere;
import meuble.Meuble;
import poste.NombrePosteFabrication;
// import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "NombrePosteServlet", value = "/NombrePosteServlet")
public class NombrePosteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getRequestDispatcher("ajout_matierePremiere.jsp").forward(request, response);
        try {
            Meuble meuble = new Meuble();
            ArrayList<Meuble> list_meuble = meuble.getAllMeuble(null);

            NombrePosteFabrication nombrePosteFabrication = new NombrePosteFabrication();
            ArrayList<NombrePosteFabrication> list_nombre_poste_fabrication =nombrePosteFabrication.getListNombrePosteFabrications(null);

            request.setAttribute("listMeuble",list_meuble);
            request.setAttribute("listNombrePosteFabrication",list_nombre_poste_fabrication);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Form_NombrePoste.jsp");
        dispat.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String meuble = request.getParameter("meuble");        
            int nbPoste = Integer.parseInt(request.getParameter("nbPoste"));
            int horaire = Integer.parseInt(request.getParameter("horaire"));

            Meuble m = new Meuble();
            m.setIdMeuble(Integer.parseInt(meuble));

           NombrePosteFabrication np = new NombrePosteFabrication();
            np.setMeuble(m);
            np.setNbOuvrier(nbPoste);
            np.setHeure_travail(horaire);

           np.insertNombrePosteFabrication(null);
        }catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        response.sendRedirect("NombrePosteServlet");
    }
}