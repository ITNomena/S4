package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import matiere.Matiere;
// import jakarta.servlet.annotation.*;
import meuble.Meuble;
import poste.Poste;
import poste.PosteFabrication;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "PosteFabricationServlet", value = "/PosteFabricationServlet")
public class PosteFabricationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getRequestDispatcher("ajout_matierePremiere.jsp").forward(request, response);
        try {
            String erreur = request.getParameter("erreur");

            if (erreur!=null && !erreur.isEmpty()) {
                request.setAttribute("erreur",erreur);
            }

            Meuble meuble = new Meuble();
            ArrayList<Meuble> list_meuble = meuble.getAllMeuble(null);

            Poste p = new Poste();
            ArrayList<Poste> list_poste = p.getAllPoste(null);

            request.setAttribute("listMeuble",list_meuble);
            request.setAttribute("listPoste",list_poste);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Form_PosteFabrication.jsp");
        dispat.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String poste = request.getParameter("poste");        
            String meuble = request.getParameter("meuble");
            int quantite = Integer.parseInt(request.getParameter("quantite"));

            Poste p = new Poste();
            p.setIdPoste(Integer.parseInt(poste));

            Meuble m = new Meuble();
            m.setIdMeuble(Integer.parseInt(meuble));

            PosteFabrication pf = new PosteFabrication();
            pf.setPoste(p);
            pf.setMeuble(m);
            pf.setQuantite(quantite);

            pf.insertPosteFabrication(null,m.getIdMeuble());

            response.sendRedirect("PosteFabricationServlet");

        }catch (Exception e) {
            //throw new RuntimeException(e);
            // e.printStackTrace();
            // System.out.println(e.getMessage());
            response.sendRedirect("PosteFabricationServlet?erreur="+e.getMessage());
        }
    }
}
