package servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import matiere.Matiere;
import matiere.MatiereStyle;
import jakarta.servlet.annotation.*;
import style.Styles;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AjoutMatiereStyleServlet", value = "/AjoutMatiereStyleServlet")
public class AjoutMatiereStyle extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Matiere matiere = new Matiere();
            ArrayList<Matiere> list_matiere = matiere.getAllMatiere(null);
            
            Styles style = new Styles();
            ArrayList<Styles> list_style = style.getAllStyle(null);

            request.setAttribute("listMatiere",list_matiere);            
            request.setAttribute("listStyle",list_style);
            
        } catch (Exception e) {
            e.printStackTrace();
            // System.out.println(e.getMessage());
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Form_MatiereStyle.jsp");
        dispat.forward(request,response); 
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String style = request.getParameter("style");            
            String matiere = request.getParameter("matiere");

            Styles stl = new Styles();
            stl.setidStyle(Integer.parseInt(style));

            Matiere mt = new Matiere();
            mt.setidMatiere(Integer.parseInt(matiere));

            MatiereStyle matiereStyle = new MatiereStyle(stl, mt);
            matiereStyle.insertMatiere_style(null);
            
        }catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

        RequestDispatcher dispat = request.getRequestDispatcher("/MatiereStyle.jsp");
        dispat.forward(request,response); 

    }
}
