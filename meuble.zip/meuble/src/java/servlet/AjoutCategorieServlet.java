package servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import categorie.Categorie;
import style.Styles;

import java.io.IOException;

@WebServlet(name = "AjoutCategorieServlet", value = "/AjoutCategorieServlet")
public class AjoutCategorieServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("ajout_categorie.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String categorie = request.getParameter("categorie");
        Categorie categorie1 = new Categorie(categorie);

        try {
            categorie1.insertCategorie(null);
        }catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}
