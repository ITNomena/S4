package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
// import matiere.Matiere;
import employe.Employe;
// import jakarta.servlet.annotation.*;
import poste.*;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AjoutEmployeServlet", value = "/AjoutEmployeServlet")
public class AjoutEmployeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getRequestDispatcher("ajout_matierePremiere.jsp").forward(request, response);
        try {
            Employe employe = new Employe();
            ArrayList<Employe> list_employe = employe.getAllEmploye(null);

            request.setAttribute("listEmploye",list_employe);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Form_Employe.jsp");
        dispat.forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String nom = request.getParameter("nom");        
            String prenom = request.getParameter("prenom");
            String dateNaissance = request.getParameter("dateNaissance");

            Employe emp = new Employe(nom,prenom,dateNaissance);
            emp.insertEmploye(null);
            
        }catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        response.sendRedirect("AjoutEmployeServlet");
    }
}