package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import matiere.Matiere;
import meuble.Meuble;
// import jakarta.servlet.annotation.*;
import poste.*;
import java.io.IOException;
import java.util.ArrayList;

import employe.RecrutementEmploye;

@WebServlet(name = "TauxHoraireServlet", value = "/TauxHoraireServlet")
public class TauxHoraireServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // request.getRequestDispatcher("ajout_matierePremiere.jsp").forward(request, response);
        try {
            RecrutementEmploye employe = new RecrutementEmploye();
            ArrayList<RecrutementEmploye> list_employe = employe.getTauxHoraire(null);

            request.setAttribute("listEmploye",list_employe);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/TauxHoraire.jsp");
        dispat.forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            
        }catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        // response.sendRedirect("TauxHoraireServlet");
    }
}