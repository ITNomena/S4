package servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import matiere.Matiere;
import meuble.Meuble;
import style.Styles;
import volume.Volume;
import jakarta.servlet.annotation.*;
import categorie.Categorie;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "AjoutMeubleServlet", value = "/AjoutMeubleServlet")
public class AjoutMeubleServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Categorie categorie = new Categorie();
            ArrayList<Categorie> list_categorie = categorie.getAllCategorie(null);
            
            Styles style = new Styles();
            ArrayList<Styles> list_style = style.getAllStyle(null);

            Volume volume = new Volume();
            List<Volume> list_volume = volume.getAllVolume(null);

            Meuble meuble = new Meuble();
            ArrayList<Meuble> list_meuble = meuble.getListMeuble(null);
        

            request.setAttribute("listCategorie",list_categorie);            
            request.setAttribute("listStyle",list_style);            
            request.setAttribute("listVolume",list_volume);
            request.setAttribute("listMeuble",list_meuble);

            
        } catch (Exception e) {
            e.printStackTrace();
            // System.out.println(e.getMessage());
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/Form_Meuble.jsp");
        dispat.forward(request,response); 
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String nom = request.getParameter("nom");                
            String categorie = request.getParameter("categorie");        
            String style = request.getParameter("style");
            String volume = request.getParameter("volume");

            Categorie cat = new Categorie();
            cat.setidCategorie(Integer.parseInt(categorie));

            Styles st = new Styles();
            st.setidStyle(Integer.parseInt(style));

            Volume vl = new Volume();
            vl.setidVolume(Integer.parseInt(volume));

            Meuble meuble = new Meuble(nom,cat,st,vl);
            meuble.insertMeuble(null);
        }catch (Exception e) {
            //throw new RuntimeException(e);
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        response.sendRedirect("AjoutMeubleServlet");
    }
}
