/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;
import genre.Genre;
import poste.NombrePosteFabrication;
import poste.Poste;

/**
 *
 * @author 1
 */
public class Client {
    public int idClient;
    public String nom;
    public String prenom;
    public Genre genre;

    public Client() {

    }

    public Client(String nom, String prenom,Genre genre) {
        this.setNom(nom);
        this.setPrenom(prenom);
        this.setGenre(genre);
    }

    public Client(int idClient,String nom, String prenom,Genre genre) {
        this.setIdClient(idClient);
        this.setNom(nom);
        this.setPrenom(prenom);
        this.setGenre(genre);
    }

    public ArrayList<Client> getAllClient(Connection connect) throws Exception {
        ArrayList<Client> list_client = new ArrayList<Client>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select client.idclient,client.nom,client.prenom,genre.genre as genre from client join genre on genre.idgenre=client.idgenre";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Genre g = new Genre();
            g.setGenre(rs.getString("genre"));

            Client client = new Client(rs.getInt("idClient"),rs.getString("nom"),rs.getString("prenom"),genre);

            list_client.add(client);
        }
        rs.close();
        st.close();
        connect.close();

        return list_client;
    }

    public void insertClient(Connection connect)throws Exception {
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into client (nom,prenom,idgenre) values ('"+this.getNom()+"','"+this.getPrenom()+"',"+this.getGenre().getIdGenre()+")";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdClient() {
        return idClient;
    }
    public void setIdClient(int idClient) {
        this.idClient = idClient;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public String getPrenom() {
        return prenom;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
    public Genre getGenre() {
        return genre;
    }
    public void setGenre(Genre genre) {
        this.genre = genre;
    }
}
