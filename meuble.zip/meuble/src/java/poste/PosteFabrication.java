/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poste;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import affichage.Benefice;
import connection.MyConnection;
import fabrication.HistoriqueFabricationMeuble;
import meuble.Meuble;

/**
 *
 * @author 1
 */
public class PosteFabrication {
    public int idPosteFabrication;
    public Poste poste;
    public Meuble meuble;
    public int quantite;

    public PosteFabrication() {

    }

    public PosteFabrication(int idPosteFabrication,Poste poste, Meuble meuble,int quantite) {
        this.setIdPosteFabrication(idPosteFabrication);
        this.setPoste(poste);
        this.setMeuble(meuble);
        this.setQuantite(quantite);
    }

    public ArrayList<Benefice> getBenefice(Connection connect,double min,double max)throws Exception {
        ArrayList<Benefice> listBenefice = new ArrayList<Benefice>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from v_benefice where benefice>="+min+" and benefice<="+max;
        // System.out.println(query);
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Benefice bn = new Benefice(rs.getInt("idmeuble"),rs.getString("meuble"),rs.getDouble("prix_total"),rs.getDouble("benefice"));

            listBenefice.add(bn);
        }
        rs.close();
        st.close();
        connect.close();

        return listBenefice;
    }

    public double getPrixRevient(Connection connect) throws Exception {
        double prix_revient = 0;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from v_prix_revient";
        // System.out.println(query);
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            prix_revient = rs.getInt("prix_total");
        }
        rs.close();
        st.close();
        connect.close();

        return prix_revient;
    }

    public void insertPosteFabrication(Connection connect,int idmeuble)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        NombrePosteFabrication nbpostefabrication = new NombrePosteFabrication().getNombreOuvrierMeuble(connect, idmeuble);
        int nbouvrier = this.getNombreOuvrierMeuble(connect, idmeuble);

        if (nbpostefabrication.getNbOuvrier() == nbouvrier) {
            throw new Exception("Ouvrier plein!!");
        } 

        String query="insert into postefabrication(idposte,idmeuble,quantite) values("+this.getPoste().getIdPoste()+","+this.getMeuble().getIdMeuble()+","+this.getQuantite()+")";
        System.out.println(query);
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getNombreOuvrierMeuble(Connection connect,int idmeuble) throws Exception {
        int nbouvrier = 0;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select sum(quantite) as nbouvrier from postefabrication where idmeuble="+idmeuble;
        System.out.println(query);
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            nbouvrier = rs.getInt("nbouvrier");
        }
        // rs.close();
        // st.close();
        // connect.close();

        return nbouvrier;
    }

    public int getIdPosteFabrication() {
        return idPosteFabrication;
    }
    public void setIdPosteFabrication(int idPosteFabrication) {
        this.idPosteFabrication = idPosteFabrication;
    }
    public Poste getPoste() {
        return poste;
    }
    public void setPoste(Poste poste) {
        this.poste = poste;
    }
    public Meuble getMeuble() {
        return meuble;
    }
    public void setMeuble(Meuble meuble) {
        this.meuble = meuble;
    }
    public int getQuantite() {
        return quantite;
    }
    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }
}
