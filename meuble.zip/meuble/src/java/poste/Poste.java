/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poste;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;
import matiere.Matiere;

/**
 *
 * @author 1
 */
public class Poste {
    public int idPoste;
    public String nom;
    public double salaire;

    public Poste() {

    }

    public Poste(String nom, double salaire) {
        this.setNom(nom);
        this.setSalaire(salaire);
    }

    public Poste(int idPoste, String nom, double salaire) {
        this.setIdPoste(idPoste);
        this.setNom(nom);
        this.setSalaire(salaire);
    }

    public ArrayList<Poste> getAllPoste(Connection connect) throws Exception {
        ArrayList<Poste> list_poste = new ArrayList<Poste>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select * from poste";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Poste poste = new Poste(rs.getInt("idposte"),rs.getString("nom"),rs.getDouble("salaire"));
            list_poste.add(poste);
        }
        rs.close();
        st.close();
        connect.close();

        return list_poste;
    }

    public void insertPoste(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into poste(nom,salaire) values('"+this.getNom()+"',"+this.getSalaire()+")";
        System.out.println(query);
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }



    public int getIdPoste() {
        return idPoste;
    }
    public void setIdPoste(int idPoste) {
        this.idPoste = idPoste;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public double getSalaire() {
        return salaire;
    }
    public void setSalaire(double salaire) {
        this.salaire = salaire;
    }
}
