/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poste;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;
import matiere.Matiere;
import meuble.Meuble;
import stock.StockMatiere;

/**
 *
 * @author 1
 */
public class NombrePosteFabrication {
    public int idNbPosteFabrication;
    public Meuble meuble;
    public int nbOuvrier;
    public int heure_travail;

    public NombrePosteFabrication() {

    }

    public NombrePosteFabrication(Meuble meuble,int nbOuvrier,int heure_travail) {
        this.setMeuble(meuble);
        this.setNbOuvrier(nbOuvrier);
        this.setHeure_travail(heure_travail);
    }

    public NombrePosteFabrication(int idNbPosteFabrication,Meuble meuble,int nbOuvrier,int heure_travail) {
        this.setIdNbPosteFabrication(idNbPosteFabrication);
        this.setMeuble(meuble);
        this.setNbOuvrier(nbOuvrier);
        this.setHeure_travail(heure_travail);
    }

    public ArrayList<NombrePosteFabrication> getListNombrePosteFabrications(Connection connect) throws Exception {
        ArrayList<NombrePosteFabrication> list_nombre_poste_fabrication = new ArrayList<NombrePosteFabrication>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select meuble.nom as meuble,nombrepostefabrication.nbouvrier,nombrepostefabrication.heure_travail from nombrepostefabrication join meuble on meuble.idmeuble=nombrepostefabrication.idmeuble";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Meuble meuble = new Meuble();
            meuble.setNom(rs.getString("meuble"));

            NombrePosteFabrication nombrePosteFabrication = new NombrePosteFabrication(meuble, rs.getInt("nbouvrier"), rs.getInt("heure_travail"));
            list_nombre_poste_fabrication.add(nombrePosteFabrication);
        }
        rs.close();
        st.close();
        connect.close();

        return list_nombre_poste_fabrication;
    }

    public NombrePosteFabrication getNombreOuvrierMeuble(Connection connect,int idmeuble) throws Exception {
        NombrePosteFabrication nombrePosteFabrication = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select * from nombrepostefabrication where idmeuble="+idmeuble;
        System.out.println(query);
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Meuble m = new Meuble();
            m.setIdMeuble(rs.getInt("idmeuble"));

            nombrePosteFabrication = new NombrePosteFabrication(rs.getInt("idnbpostefabrication"),m,rs.getInt("nbouvrier"),rs.getInt("heure_travail"));
            
        }
        // rs.close();
        // st.close();
        // connect.close();

        return nombrePosteFabrication;
    }

    public void insertNombrePosteFabrication(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into nombrepostefabrication(idmeuble,nbouvrier,heure_travail) values("+this.getMeuble().getIdMeuble()+","+this.getNbOuvrier()+","+this.getHeure_travail()+")";
        System.out.println(query);
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    public int getIdNbPosteFabrication() {
        return idNbPosteFabrication;
    }
    public void setIdNbPosteFabrication(int idNbPosteFabrication) {
        this.idNbPosteFabrication = idNbPosteFabrication;
    }
    public Meuble getMeuble() {
        return meuble;
    }
    public void setMeuble(Meuble meuble) {
        this.meuble = meuble;
    }
    public int getNbOuvrier() {
        return nbOuvrier;
    }
    public void setNbOuvrier(int nbOuvrier) {
        this.nbOuvrier = nbOuvrier;
    }
    public int getHeure_travail() {
        return heure_travail;
    }
    public void setHeure_travail(int heure_travail) {
        this.heure_travail = heure_travail;
    }
}
