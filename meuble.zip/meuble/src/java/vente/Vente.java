/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vente;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import client.Client;
import connection.MyConnection;
import meuble.Meuble;

/**
 *
 * @author 1
 */
public class Vente {
    public int idVente;
    public Date date_vente;
    public Client client;
    public Meuble meuble;
    public int quantite;

    public String date_vente_string;
    public int nb_homme;
    public int nb_femme;

    public Vente() {

    }

    public Vente(String date_vente,Client client,Meuble meuble,int quantite) {
        this.setDate_vente_string(date_vente);
        this.setClient(client);
        this.setMeuble(meuble);
        this.setQuantite(quantite);
    }

    public Vente(Date date,Client client,Meuble meuble,int quantite) {
        this.setDate_vente(date);
        this.setClient(client);
        this.setMeuble(meuble);
        this.setQuantite(quantite);
    }

    public Vente(int idVente,Date date,Client client,Meuble meuble,int quantite) {
        this.setIdVente(idVente);
        this.setDate_vente(date);
        this.setClient(client);
        this.setMeuble(meuble);
        this.setQuantite(quantite);
    }

    public Vente(Meuble meuble,int nb_homme,int nb_femme) {
        this.setMeuble(meuble);
        this.setNb_homme(nb_homme);
        this.setNb_femme(nb_femme);
    }

    public Vente(Meuble meuble,int quantite) {
        this.setMeuble(meuble);
        this.setQuantite(quantite);
    }

    public Vente getMeubleRestantByIdMeuble(Connection connect,int idmeuble,int quantite) throws Exception {
        Vente vente = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from v_meuble_restant where idmeuble="+idmeuble;
        System.out.println(query);
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Meuble m = new Meuble();
            m.setIdMeuble(rs.getInt("idmeuble"));
            m.setNom(rs.getString("nom"));

            vente = new Vente(m,rs.getInt("quantite"));
        }

        if (vente.getQuantite()-quantite < 0) {
            throw new Exception("Stock insuffisant!!");
        }

        rs.close();
        st.close();
        connect.close();

        return vente;
    }

    public Vente getSumParGenreByMeuble(Connection connect,int idmeuble) throws Exception {
        Vente vente = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select sum(nombre_hommes) as nb_homme,sum(nombre_femmes) as nb_femme from v_stat where idmeuble="+idmeuble;
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            vente = new Vente();
            vente.setNb_homme(rs.getInt("nb_homme"));
            vente.setNb_femme(rs.getInt("nb_femme"));
        }
        rs.close();
        st.close();
        connect.close();

        return vente;
    }

    public Vente getSumParGenre(Connection connect) throws Exception {
        Vente vente = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select sum(nombre_hommes) as nb_homme,sum(nombre_femmes) as nb_femme from v_stat";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            vente = new Vente();
            vente.setNb_homme(rs.getInt("nb_homme"));
            vente.setNb_femme(rs.getInt("nb_femme"));
        }
        rs.close();
        st.close();
        connect.close();

        return vente;
    }
    
    public ArrayList<Vente> getStatByMeuble(Connection connect,int idMeuble)throws Exception {
        ArrayList<Vente> listStats = new ArrayList<Vente>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from v_stat where idmeuble="+idMeuble;
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Meuble m = new Meuble();
            m.setIdMeuble(rs.getInt("idmeuble"));
            m.setNom(rs.getString("nom"));

            Vente p = new Vente(m,rs.getInt("nombre_hommes"),rs.getInt("nombre_femmes"));

            listStats.add(p);
        }
        rs.close();
        st.close();
        connect.close();

        return listStats;
    }

    public ArrayList<Vente> getStat(Connection connect)throws Exception {
        ArrayList<Vente> listStats = new ArrayList<Vente>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from v_stat";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Meuble m = new Meuble();
            m.setIdMeuble(rs.getInt("idmeuble"));
            m.setNom(rs.getString("nom"));
            
            Vente p = new Vente(m,rs.getInt("nombre_hommes"),rs.getInt("nombre_femmes"));

            listStats.add(p);
        }
        rs.close();
        st.close();
        connect.close();

        return listStats;
    }

    public ArrayList<Vente> getAllVente(Connection connect)throws Exception {
        ArrayList<Vente> listVente = new ArrayList<Vente>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select vente.idvente,vente.date_vente,client.nom as client,meuble.nom as meuble,vente.quantite from vente join client on client.idclient=vente.idclient join meuble on meuble.idmeuble=vente.idmeuble";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Client c = new Client();
            c.setNom(rs.getString("client"));

            Meuble m = new Meuble();
            m.setNom(rs.getString("meuble"));

            Vente p = new Vente(rs.getInt("idVente"),rs.getDate("date_vente"),c,m,rs.getInt("quantite"));

            listVente.add(p);
        }
        rs.close();
        st.close();
        connect.close();

        return listVente;
    }

    public void insertVente(Connection connect)throws Exception {
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into vente (date_vente,idclient,idmeuble,quantite) values ('"+this.getDate_vente_string()+"','"+this.getClient().getIdClient()+"',"+this.getMeuble().getIdMeuble()+","+this.getQuantite()+")";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdVente() {
        return idVente;
    }
    public void setIdVente(int idVente) {
        this.idVente = idVente;
    }
    public Date getDate_vente() {
        return date_vente;
    }
    public void setDate_vente(Date date_vente) {
        this.date_vente = date_vente;
    }
    public Client getClient() {
        return client;
    }
    public void setClient(Client client) {
        this.client = client;
    }
    public Meuble getMeuble() {
        return meuble;
    }
    public void setMeuble(Meuble meuble) {
        this.meuble = meuble;
    }
    public int getQuantite() {
        return quantite;
    }
    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }
    public String getDate_vente_string() {
        return date_vente_string;
    }

    public void setDate_vente_string(String date_vente_string) {
        this.date_vente_string = date_vente_string;
    }
    public int getNb_homme() {
        return nb_homme;
    }

    public void setNb_homme(int nb_homme) {
        this.nb_homme = nb_homme;
    }

    public int getNb_femme() {
        return nb_femme;
    }

    public void setNb_femme(int nb_femme) {
        this.nb_femme = nb_femme;
    }
}
