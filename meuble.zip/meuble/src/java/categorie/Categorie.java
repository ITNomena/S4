/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package categorie;
import connection.*;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author itu
 */
public class Categorie {
    int idCategorie;
    String nom;

    public Categorie() {
        
    }

    public Categorie(String nom) {
        this.setnom(nom);
    }

    public Categorie(int idCategorie, String nom) {
        this.setidCategorie(idCategorie);
        this.setnom(nom);
    }

    public ArrayList<Categorie> getAllCategorie(Connection connect) throws Exception {
        ArrayList<Categorie> list_categorie = new ArrayList<Categorie>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select * from categorie";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Categorie categorie = new Categorie(rs.getInt(1),rs.getString(2));
            list_categorie.add(categorie);
        }
        rs.close();
        st.close();
        connect.close();

        return list_categorie;
    }

    public void insertCategorie(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into categorie(nom) values('"+this.getnom()+"')";
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    } 

    public int getidCategorie(){
        return idCategorie; 
    }
    public void setidCategorie(int newidCategorie){
        idCategorie=newidCategorie;
    } 
    public String getnom(){
        return nom; 
    }
    public void setnom(String newnom){
        nom=newnom;
    }
}
