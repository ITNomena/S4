/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package genre;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;

/**
 *
 * @author 1
 */
public class Genre {
    public int idGenre;
    public String genre;

    public Genre() {

    }

    public Genre(String genre) {
        this.setGenre(genre);
    }

    public ArrayList<Genre> getAllGenre(Connection connect)throws Exception {
        ArrayList<Genre> listGenre = new ArrayList<Genre>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from Genre";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Genre p = new Genre(rs.getInt("idgenre"),rs.getString("genre"));

            listGenre.add(p);
        }
        rs.close();
        st.close();
        connect.close();

        return listGenre;
    }

    public Genre(int idGenre,String genre) {
        this.setIdGenre(idGenre);
        this.setGenre(genre);
    }

    public int getIdGenre() {
        return idGenre;
    }
    public void setIdGenre(int idGenre) {
        this.idGenre = idGenre;
    }
    public String getGenre() {
        return genre;
    }
    public void setGenre(String genre) {
        this.genre = genre;
    }
}
