/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package volume;
import connection.*;
import matiere.Matiere;
import style.Styles;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author itu
 */
public class Volume {
    int idVolume;
    String types;

    public Volume() {

    }

    public Volume(int idVolume,String type) {
        this.setidVolume(idVolume);
        this.settypes(type);
    }
        

    public ArrayList<Volume> getAllVolume(Connection connect) throws Exception {
        ArrayList<Volume> list_volume = new ArrayList<Volume>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select * from volume";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Volume matiere_style = new Volume(rs.getInt(1),rs.getString(2));
            list_volume.add(matiere_style);
        }
        rs.close();
        st.close();
        connect.close();

        return list_volume;
    }
    
    public void insertVolume(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into volume(types) values('"+this.gettypes()+"')";
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }    
    
    
    public int getidVolume(){
        return idVolume; 
    }
    public void setidVolume(int newidVolume){
        idVolume=newidVolume;
    } 
    public String gettypes(){
        return types; 
    }
    public void settypes(String newtypes){
        types=newtypes;
    } 
}
