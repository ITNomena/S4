/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employe;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;

/**
 *
 * @author 1
 */
public class Profil {
    public int idProfil;
    public int annee_min;
    public int annee_max;
    public String profil;

    public Profil() {

    }

    public Profil(String profil) {
        this.setProfil(profil);
    }

    public Profil(int idProfil,int annee_min,int annee_max,String profil) {
        this.setIdProfil(idProfil);
        this.setAnnee_min(annee_min);
        this.setAnnee_max(annee_max);
        this.setProfil(profil);
    }


    public ArrayList<Profil> getAllProfil(Connection connect)throws Exception {
        ArrayList<Profil> listProfil = new ArrayList<Profil>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from profil";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Profil p = new Profil(rs.getInt("idprofil"),rs.getInt("annee_min"),rs.getInt("annee_max"),rs.getString("profil"));

            listProfil.add(p);
        }
        rs.close();
        st.close();
        connect.close();

        return listProfil;
    }


    public void insertProfil(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into profil (annee_min,annee_max,profil) values("+this.getAnnee_min()+","+this.getAnnee_max()+",'"+this.getProfil()+"')";
        System.out.println(query);
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    public int getIdProfil() {
        return idProfil;
    }
    public void setIdProfil(int idProfil) {
        this.idProfil = idProfil;
    }
    public int getAnnee_min() {
        return annee_min;
    }
    public void setAnnee_min(int annee_min) {
        this.annee_min = annee_min;
    }
    public int getAnnee_max() {
        return annee_max;
    }
    public void setAnnee_max(int annee_max) {
        this.annee_max = annee_max;
    }
    public String getProfil() {
        return profil;
    }
    public void setProfil(String profil) {
        this.profil = profil;
    }
}
