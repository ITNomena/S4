/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employe;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;
import poste.Poste;

/**
 *
 * @author 1
 */
public class RecrutementEmploye {
    public int idRecrutementEmploye;
    public Date dateRecrutement;
    public Employe employe;
    public Poste poste;

    Profil profil;
    public String date_recrutement;

    public RecrutementEmploye() {

    }

    public RecrutementEmploye(String dateRecrutement,Employe employe,Poste poste) {
        this.setDateRecrutement_String(dateRecrutement);
        this.setEmploye(employe);
        this.setPoste(poste);
    }

    public RecrutementEmploye(Date dateRecrutement,Employe employe,Poste poste) {
        this.setDateRecrutement(dateRecrutement);
        this.setEmploye(employe);
        this.setPoste(poste);
    }

    public RecrutementEmploye(int idRecrutementEmploye,Date dateRecrutement,Employe employe,Poste poste) {
        this.setIdRecrutementEmploye(idRecrutementEmploye);
        this.setDateRecrutement(dateRecrutement);
        this.setEmploye(employe);
        this.setPoste(poste);
    }

    public RecrutementEmploye(int idRecrutementEmploye,Date dateRecrutement,Employe employe,Poste poste,Profil profil) {
        this.setIdRecrutementEmploye(idRecrutementEmploye);
        this.setDateRecrutement(dateRecrutement);
        this.setEmploye(employe);
        this.setPoste(poste);
        this.setProfil(profil);
    }

    public ArrayList<RecrutementEmploye> getAllRecrutement(Connection connect)throws Exception {
        ArrayList<RecrutementEmploye> listRecrutementEmploye = new ArrayList<RecrutementEmploye>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select re.date_recrutement,employe.nom,employe.prenom,poste.nom as poste from recrutementemploye as re join employe on employe.idemploye=re.idemploye join poste on poste.idposte=re.idposte";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Employe employe = new Employe();
            employe.setNom(rs.getString("nom"));
            employe.setPrenom(rs.getString("prenom"));

            Poste poste = new Poste();
            poste.setNom("poste");

            RecrutementEmploye recrutementEmploye = new RecrutementEmploye(rs.getDate("date_recrutement"),employe,poste);

            listRecrutementEmploye.add(recrutementEmploye);
        }

        rs.close();
        st.close();
        connect.close();

        return listRecrutementEmploye;
    }

    public ArrayList<RecrutementEmploye> getTauxHoraire(Connection connect)throws Exception {
        ArrayList<RecrutementEmploye> listRecrutementEmploye = new ArrayList<RecrutementEmploye>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from v_taux_horaire";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Employe employe = new Employe();
            employe.setNom(rs.getString("nom"));
            employe.setPrenom(rs.getString("prenom"));
            employe.setTaux_horaire(rs.getDouble("taux_horaire"));

            Poste poste = new Poste();
            poste.setNom(rs.getString("poste"));

            Profil profil = new Profil();
            profil.setProfil(rs.getString("profil"));

            RecrutementEmploye recrutementEmploye = new RecrutementEmploye(rs.getInt("idrecrutementemploye"),rs.getDate("date_recrutement"),employe,poste,profil);

            listRecrutementEmploye.add(recrutementEmploye);
        }

        rs.close();
        st.close();
        connect.close();

        return listRecrutementEmploye;
    }

    public void insertRecrutementEmploye(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into recrutementemploye (date_recrutement,idemploye,idposte) values('"+this.getDateRecrutement_String()+"',"+this.getEmploye().getIdEmploye()+","+this.getPoste().getIdPoste()+")";
        System.out.println(query);
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdRecrutementEmploye() {
        return idRecrutementEmploye;
    }
    public void setIdRecrutementEmploye(int idRecrutementEmploye) {
        this.idRecrutementEmploye = idRecrutementEmploye;
    }
    public Date getDateRecrutement() {
        return dateRecrutement;
    }
    public void setDateRecrutement(Date dateRecrutement) {
        this.dateRecrutement = dateRecrutement;
    }
    public String getDateRecrutement_String() {
        return date_recrutement;
    }
    public void setDateRecrutement_String(String date_recrutement) {
        this.date_recrutement = date_recrutement;
    }
    public Employe getEmploye() {
        return employe;
    }
    public void setEmploye(Employe employe) {
        this.employe = employe;
    }
    public Poste getPoste() {
        return poste;
    }
    public void setPoste(Poste poste) {
        this.poste = poste;
    }
    public Profil getProfil() {
        return profil;
    }
    public void setProfil(Profil profil) {
        this.profil = profil;
    }
}
