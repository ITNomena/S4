/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employe;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;
import poste.NombrePosteFabrication;

/**
 *
 * @author 1
 */
public class Employe {
    public int idEmploye;
    public String nom;
    public String prenom;
    public Date dateNaissance;

    public double taux_horaire;
    public String date_naissance;


    public Employe() {

    }

    public Employe(String nom,String prenom,double taux_horaire) {
        this.setNom(nom);
        this.setPrenom(prenom);
        this.setTaux_horaire(taux_horaire);
    }

    public Employe(String nom,String prenom,String date_naissance) {
        this.setNom(nom);
        this.setPrenom(prenom);
        this.setDateNaissance_String(date_naissance);
    }

    public Employe(String nom,String prenom,Date dateNaissance) {
        this.setNom(nom);
        this.setPrenom(prenom);
        this.setDateNaissance(dateNaissance);
    }

    public Employe(int idEmploye,String nom,String prenom,Date dateNaissance) {
        this.setIdEmploye(idEmploye);
        this.setNom(nom);
        this.setPrenom(prenom);
        this.setDateNaissance(dateNaissance);
    }

    public ArrayList<Employe> getAllEmploye(Connection connect)throws Exception {
        ArrayList<Employe> listEmploye = new ArrayList<Employe>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from employe";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Employe emp = new Employe(rs.getInt("idEmploye"),rs.getString("nom"),rs.getString("prenom"),rs.getDate("datenaissance"));

            listEmploye.add(emp);
        }
        rs.close();
        st.close();
        connect.close();

        return listEmploye;
    }


    public void insertEmploye(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into employe (nom,prenom,datenaissance) values('"+this.getNom()+"','"+this.getPrenom()+"','"+this.getDateNaissance_String()+"')";
        System.out.println(query);
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    public int getIdEmploye() {
        return idEmploye;
    }
    public void setIdEmploye(int idEmploye) {
        this.idEmploye = idEmploye;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public String getPrenom() {
        return prenom;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
    public Date getDateNaissance() {
        return dateNaissance;
    }
    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }
    public String getDateNaissance_String() {
        return date_naissance;
    }
    public void setDateNaissance_String(String date_naissance) {
        this.date_naissance = date_naissance;
    }
    public double getTaux_horaire() {
        return taux_horaire;
    }
    public void setTaux_horaire(double taux_horaire) {
        this.taux_horaire = taux_horaire;
    }
    
}
