/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fabrication;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import meuble.Meuble;
import connection.MyConnection;
import matiere.Matiere;
import matiere.MatiereStyle;
import meuble.Meuble;
import style.Styles;
import volume.Volume;

/**
 *
 * @author 1
 */
public class Fabrication {
    int idFabrication;
    Meuble meuble;
    MatiereStyle matiereStyle;
    int quantite;

    public Fabrication() {

    }

    public Fabrication(Meuble meuble,MatiereStyle matiereStyle, int quantite) {
        this.setMeuble(meuble);
        this.setMatiereStyle(matiereStyle);
        this.setQuantite(quantite);
    }

    public ArrayList<Fabrication> getFabricationByMeuble(Connection connect,int idmeuble) throws Exception{
        ArrayList<Fabrication> list_meuble = new ArrayList<Fabrication>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select fabrication.*,matiere_style.idmatiere from fabrication join matiere_style on matiere_style.idms=fabrication.idms where idmeuble="+idmeuble;
        System.out.println(query);
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Meuble m = new Meuble();
            m.setIdMeuble(rs.getInt("idmeuble"));

            Matiere mt = new Matiere();
            mt.setidMatiere(rs.getInt("idmatiere"));

            MatiereStyle mts = new MatiereStyle();
            mts.setidMS(rs.getInt("idms"));
            mts.setmatiere(mt);

            Fabrication fb = new Fabrication();
            fb.setIdFabrication(rs.getInt("idfabrication"));
            fb.setMeuble(m);
            fb.setMatiereStyle(mts);
            fb.setQuantite(rs.getInt("quantite"));
            
            list_meuble.add(fb);
        }
        // rs.close();
        // st.close();
        // connect.close();

        return list_meuble;
    }

    public ArrayList<Fabrication> getMeuble(Connection connect,double min, double max) throws Exception{
        ArrayList<Fabrication> list_meuble = new ArrayList<Fabrication>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select * from v_sum_prix where prix>"+min+" and prix<"+max;
        System.out.println(query);
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {

            Meuble m = new Meuble();
            m.setIdMeuble(rs.getInt("idmeuble"));
            m.setNom(rs.getString("meuble"));

            Matiere mt = new Matiere();
            mt.setPrix(rs.getDouble("prix"));

            MatiereStyle mts = new MatiereStyle();
            mts.setmatiere(mt);

            Fabrication fb = new Fabrication();
            fb.setMeuble(m);
            fb.setMatiereStyle(mts);
            
            list_meuble.add(fb);
        }
        rs.close();
        st.close();
        connect.close();

        return list_meuble;
    }

    public static ArrayList<Fabrication> getAllFabrication(Connection connect) throws Exception{
        ArrayList<Fabrication> list_fabrication = new ArrayList<Fabrication>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select * from v_fabrication";

        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Volume volume = new Volume();
            volume.settypes(rs.getString("volume"));

            Meuble meuble = new Meuble();
            meuble.setIdMeuble(rs.getInt("idmeuble"));
            meuble.setNom(rs.getString("meuble"));
            meuble.setVolume(volume);

            Styles styles = new Styles();
            styles.setnom(rs.getString("style"));

            MatiereStyle matiereStyle = new MatiereStyle();
            matiereStyle.setstyle(styles);

            Fabrication fabrication = new Fabrication();
            fabrication.setMeuble(meuble);
            fabrication.setMatiereStyle(matiereStyle);
            fabrication.setQuantite(rs.getInt("quantite"));

            list_fabrication.add(fabrication);
        }
        rs.close();
        st.close();
        connect.close();

        return list_fabrication;
    }

    public static ArrayList<Fabrication> getFabricationByMatiere(Connection connect,String matiere) throws Exception{
        ArrayList<Fabrication> list_fabrication = new ArrayList<Fabrication>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select meuble.nom as meuble,volume.types as volume,style.nom as style,fabrication.quantite as quantite,fabrication.quantite*matiere.prix as prix from fabrication  \r\n" + //
                "join matiere_style on matiere_style.idMS=fabrication.idMS " +
                "join style on matiere_style.idStyle=style.idStyle " +
                "join meuble on meuble.idmeuble=fabrication.idmeuble " +
                "join matiere on matiere_style.idMatiere=matiere.idMatiere " +
                "join volume on volume.idVolume=meuble.idVolume " +
                "where matiere_style.idMatiere="+Integer.parseInt(matiere);

        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Volume volume = new Volume();
            volume.settypes(rs.getString("volume"));

            Meuble meuble = new Meuble();
            meuble.setNom(rs.getString("meuble"));
            meuble.setVolume(volume);

            Styles styles = new Styles();
            styles.setnom(rs.getString("style"));

            MatiereStyle matiereStyle = new MatiereStyle();
            matiereStyle.setstyle(styles);

            Fabrication fabrication = new Fabrication();
            fabrication.setMeuble(meuble);
            fabrication.setMatiereStyle(matiereStyle);
            fabrication.setQuantite(rs.getInt("quantite"));

            list_fabrication.add(fabrication);
        }
        rs.close();
        st.close();
        connect.close();

        return list_fabrication;
    }

    public void insertFabricatiom(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into fabrication(idMeuble,idMS,quantite) values("+this.getMeuble().getIdMeuble()+","+this.getMatiereStyle().getidMS()+","+this.getQuantite()+")";
        System.out.println(query);
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdFabrication() {
        return idFabrication;
    }

    public void setIdFabrication(int idFabrication) {
        this.idFabrication = idFabrication;
    }
    public Meuble getMeuble() {
        return meuble;
    }
    public void setMeuble(Meuble meuble) {
        this.meuble = meuble;
    }
    public MatiereStyle getMatiereStyle() {
        return matiereStyle;
    }
    public void setMatiereStyle(MatiereStyle matiereStyle) {
        this.matiereStyle = matiereStyle;
    }
    public int getQuantite() {
        return quantite;
    }
    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }
}
