/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fabrication;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;
import matiere.Matiere;
import meuble.Meuble;
import stock.StockMatiere;

/**
 *
 * @author 1
 */
public class HistoriqueFabricationMeuble {
    public int idfabricationmeuble;
    public Date date;
    public Meuble meuble;
    public int quantite;

    public HistoriqueFabricationMeuble() {

    }

    public HistoriqueFabricationMeuble(int idfabricationmeuble,Meuble meuble,int quantite) {
        this.setIdfabricationmeuble(idfabricationmeuble);
        this.setMeuble(meuble);
        this.setQuantite(quantite);
    }

    public ArrayList<HistoriqueFabricationMeuble> getMeubleFabrique(Connection connect)throws Exception {
        ArrayList<HistoriqueFabricationMeuble> liststockMatiere = new ArrayList<HistoriqueFabricationMeuble>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from v_meuble_fabrique";
        System.out.println(query);
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Meuble m = new Meuble();
            m.setIdMeuble(rs.getInt("idmeuble"));
            m.setNom(rs.getString("nom"));

            HistoriqueFabricationMeuble historiqueFabricationMeuble = new HistoriqueFabricationMeuble();
            historiqueFabricationMeuble.setMeuble(m);
            historiqueFabricationMeuble.setQuantite(rs.getInt("sum"));

            liststockMatiere.add(historiqueFabricationMeuble);
            
        }
        rs.close();
        st.close();
        connect.close();

        return liststockMatiere;
    }

    public ArrayList<HistoriqueFabricationMeuble> getHistoriqueFabricationMeubles(Connection connect)throws Exception {
        ArrayList<HistoriqueFabricationMeuble> liststockMatiere = new ArrayList<HistoriqueFabricationMeuble>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select historiquefabricationmeuble.*,meuble.nom from historiquefabricationmeuble join meuble on meuble.idmeuble=historiquefabricationmeuble.idmeuble";
        System.out.println(query);
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Meuble m = new Meuble();
            m.setIdMeuble(rs.getInt("idmeuble"));
            m.setNom(rs.getString("nom"));

            HistoriqueFabricationMeuble historiqueFabricationMeuble = new HistoriqueFabricationMeuble();
            historiqueFabricationMeuble.setIdfabricationmeuble(rs.getInt("idfabricationmeuble"));
            historiqueFabricationMeuble.setDate(rs.getDate("date"));
            historiqueFabricationMeuble.setMeuble(m);
            historiqueFabricationMeuble.setQuantite(rs.getInt("quantite"));

            liststockMatiere.add(historiqueFabricationMeuble);
            
        }
        rs.close();
        st.close();
        connect.close();

        return liststockMatiere;
    }

    public void insertHistoriqueFabricationMeuble(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into historiquefabricationmeuble(date,idmeuble,quantite) values (CURRENT_DATE,"+this.getMeuble().getIdMeuble()+","+this.getQuantite()+")";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    

    public int getIdfabricationmeuble() {
        return idfabricationmeuble;
    }
    public void setIdfabricationmeuble(int idfabricationmeuble) {
        this.idfabricationmeuble = idfabricationmeuble;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public Meuble getMeuble() {
        return meuble;
    }
    public void setMeuble(Meuble meuble) {
        this.meuble = meuble;
    }
    public int getQuantite() {
        return quantite;
    }
    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }


}
