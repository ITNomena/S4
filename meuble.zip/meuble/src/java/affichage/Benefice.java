/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package affichage;

/**
 *
 * @author 1
 */
public class Benefice {
    public int idmeuble;
    public String meuble;
    public double prix_total;
    public double benefice;

    public Benefice() {
        
    }

    public Benefice(int idmeuble,String meuble,double prix_total,double benefice) {
        this.setIdmeuble(idmeuble);
        this.setMeuble(meuble);
        this.setPrix_total(prix_total);
        this.setBenefice(benefice);
    }

    public int getIdmeuble() {
        return idmeuble;
    }
    public void setIdmeuble(int idmeuble) {
        this.idmeuble = idmeuble;
    }
    public String getMeuble() {
        return meuble;
    }
    public void setMeuble(String meuble) {
        this.meuble = meuble;
    }
    public double getPrix_total() {
        return prix_total;
    }
    public void setPrix_total(double prix_total) {
        this.prix_total = prix_total;
    }
    public double getBenefice() {
        return benefice;
    }
    public void setBenefice(double benefice) {
        this.benefice = benefice;
    }
}
