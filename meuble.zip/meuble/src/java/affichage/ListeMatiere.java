/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package affichage;

/**
 *
 * @author itu
 */
public class ListeMatiere {
    String style;
    String matiere;
        
    public ListeMatiere(String style,String matiere){
        this.setstyle(style);
        this.setmatiere(matiere);
    }

    public ListeMatiere(String matiere){
        this.setmatiere(matiere);
    }

    public String getstyle(){
        return style; 
    }

    public void setstyle(String newstyle){
        style=newstyle;
    }

    public String getmatiere(){
        return matiere; 
    }
    
    public void setmatiere(String newmateriels){
        matiere=newmateriels;
    } 
}
