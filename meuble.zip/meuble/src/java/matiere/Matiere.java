/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package matiere;
import connection.*;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author itu
 */
public class Matiere {
    int idMatiere;
    String nom;
    double prix;

    public Matiere() {

    }

    public Matiere(String nom,double prix){
        this.setnom(nom);
        this.setPrix(prix);
    }

    public Matiere(int idMatiere,String nom,double prix){
        this.setidMatiere(idMatiere);
        this.setnom(nom);
        this.setPrix(prix);
    }
    
        
    public void insertMatiere(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into matiere(nom,prix) values('"+this.getnom()+"',"+this.getPrix()+")";
        System.out.println(query);
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    } 

    public ArrayList<Matiere> getAllMatiere(Connection connect) throws Exception {
        ArrayList<Matiere> list_matiere = new ArrayList<Matiere>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select * from matiere";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Matiere matiere = new Matiere(rs.getInt(1),rs.getString(2),rs.getDouble(3));
            list_matiere.add(matiere);
        }
        rs.close();
        st.close();
        connect.close();

        return list_matiere;
    }

    public int getidMatiere(){
        return idMatiere; 
    }
    public void setidMatiere(int newidMatiere){
        idMatiere=newidMatiere;
    } 
    public String getnom(){
        return nom; 
    }
    public void setnom(String newnom){
        nom=newnom;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }
    
}
