/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package matiere;
import style.*;
import connection.*;
import java.sql.*;
import java.util.ArrayList;
import affichage.*;
/**
 *
 * @author itu
 */
public class MatiereStyle {
    int idMS;
    Styles style;
    Matiere matiere;

    public MatiereStyle() {

    }

    public MatiereStyle(int idMS,Styles style,Matiere matiere){
        this.setidMS(idMS);
        // this.setcategorie(matiere_style);
        this.setstyle(style);
        this.setmatiere(matiere);
    }

    public MatiereStyle(Styles style,Matiere matiere){
        this.setstyle(style);
        this.setmatiere(matiere);
    }

    

    public ArrayList<MatiereStyle> getAllMatiereStyle(Connection connect) throws Exception {
        ArrayList<MatiereStyle> list_matiere_style = new ArrayList<MatiereStyle>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select matiere_style.idMS,style.nom,matiere.nom from matiere_style join style on style.idstyle=matiere_style.idstyle join matiere on matiere.idmatiere=matiere_style.idmatiere";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Styles stl = new Styles();
            stl.setnom(rs.getString(2));

            Matiere mt = new Matiere();
            mt.setnom(rs.getString(3));

            MatiereStyle matiere_style = new MatiereStyle(rs.getInt(1),stl,mt);
            list_matiere_style.add(matiere_style);
        }
        rs.close();
        st.close();
        connect.close();

        return list_matiere_style;
    }



    public void insertMatiere_style(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into matiere_style(idStyle,idMatiere) values("+this.getstyle().getidStyle()+","+this.getmatiere().getidMatiere()+")";
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    public static ArrayList<ListeMatiere> getMaterielByStyle(Connection connect,String style) throws Exception{
        ArrayList<ListeMatiere> lm=new ArrayList<ListeMatiere>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select matiere.nom as MaterielNom from matiere_style join matiere on matiere.idMatiere=matiere_style.idMatiere where matiere_style.idStyle="+Integer.parseInt(style);
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            String nomMateriel=rs.getString("MaterielNom");
            ListeMatiere listeMateriel=new ListeMatiere(nomMateriel);
            lm.add(listeMateriel);
        }
        rs.close();
        st.close();
        connect.close();

        return lm;
    }


    public int getidMS(){
        return idMS; 
    }
    public void setidMS(int newidMS){
        idMS=newidMS;
    }
    // public MatiereStyle getcategorie(){
    //     return matiere_style; 
    // }
    // public void setcategorie(MatiereStyle newcategorie){
    //     matiere_style=newcategorie;
    // }         
    public Styles getstyle(){
        return style; 
    }
    public void setstyle(Styles newstyle){
        style=newstyle;
    }         
    public Matiere getmatiere(){
        return matiere; 
    }
    public void setmatiere(Matiere newmatiere){
        matiere=newmatiere;
    }  
}
