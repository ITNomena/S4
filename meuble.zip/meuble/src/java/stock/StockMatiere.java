/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stock;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;
import fabrication.Fabrication;
import matiere.Matiere;
import matiere.MatiereStyle;
import meuble.Meuble;

/**
 *
 * @author 1
 */
public class StockMatiere {
    public int idStockMatiere;
    public Date date;
    public Matiere matiere;
    public int quantite;

    public StockMatiere() {

    }

    public StockMatiere(int idStockMatiere,Date date,Matiere matiere,int quantite) throws Exception {
        this.setIdStockMatiere(idStockMatiere);
        this.setDate(date);
        this.setMatiere(matiere);
        this.setQuantite(quantite);
    }

    public ArrayList<StockMatiere> getStockMatiere(Connection connect)throws Exception {
        ArrayList<StockMatiere> liststockMatiere = new ArrayList<StockMatiere>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select stockmatiere.*,matiere.nom from stockmatiere join matiere on matiere.idmatiere=stockmatiere.idmatiere";
        System.out.println(query);
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Matiere mt = new Matiere();
            mt.setidMatiere(rs.getInt("idmatiere"));
            mt.setnom(rs.getString("nom"));

            StockMatiere stockMatiere = new StockMatiere();
            stockMatiere.setIdStockMatiere(rs.getInt("idstockmatiere"));
            stockMatiere.setDate(rs.getDate("date"));
            stockMatiere.setMatiere(mt);
            stockMatiere.setQuantite(rs.getInt("quantite"));

            liststockMatiere.add(stockMatiere);
            
        }
        rs.close();
        st.close();
        connect.close();

        return liststockMatiere;
    }

    public void updateStockMatiere(Connection connect,int idmeuble,int quantite_meuble_fabrique)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Fabrication fb = new Fabrication();
        ArrayList<Fabrication> list_fb = fb.getFabricationByMeuble(connect, idmeuble);

        for (int i = 0; i < list_fb.size(); i++) {
            StockMatiere st = this.getStockMatiereByIdMatiere(connect, list_fb.get(i).getMatiereStyle().getmatiere().getidMatiere());

            if (list_fb.get(i).getQuantite()*quantite_meuble_fabrique > st.getQuantite()) {
                throw new Exception("Quantite insuffisante!! pour "+st.getMatiere().getnom());
            }
        }

        for (int i = 0; i < list_fb.size(); i++) {
            StockMatiere st = this.getStockMatiereByIdMatiere(connect, list_fb.get(i).getMatiereStyle().getmatiere().getidMatiere());
    
            String query = "update stockmatiere set quantite=" + (st.getQuantite() - (list_fb.get(i).getQuantite() * quantite_meuble_fabrique)) + " where idmatiere=" + list_fb.get(i).getMatiereStyle().getmatiere().getidMatiere();
            System.out.println(query);
    
            try {
                PreparedStatement ps = connect.prepareStatement(query);
                int nombreLignesAffectees = ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public StockMatiere getStockMatiereByIdMatiere(Connection connect,int idmatiere)throws Exception {
        StockMatiere stockMatiere = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select stockmatiere.*,matiere.nom from stockmatiere join matiere on matiere.idmatiere=stockmatiere.idmatiere where stockmatiere.idmatiere="+idmatiere;
        System.out.println(query);
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Matiere mt = new Matiere();
            mt.setidMatiere(rs.getInt("idmatiere"));
            mt.setnom(rs.getString("nom"));

            stockMatiere = new StockMatiere(rs.getInt("idstockmatiere"),rs.getDate("date"),mt,rs.getInt("quantite"));
            
        }
        // rs.close();
        // st.close();
        // connect.close();

        return stockMatiere;
    } 

    public void insertStockMatiere(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into stockmatiere(date,idmatiere,quantite) values(CURRENT_DATE,"+this.getMatiere().getidMatiere()+","+this.getQuantite()+")";
        System.out.println(query);
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdStockMatiere() {
        return idStockMatiere;
    }
    public void setIdStockMatiere(int idStockMatiere) {
        this.idStockMatiere = idStockMatiere;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public Matiere getMatiere() {
        return matiere;
    }
    public void setMatiere(Matiere matiere) {
        this.matiere = matiere;
    }
    public int getQuantite() {
        return quantite;
    }
    public void setQuantite(int quantite) throws Exception {
        if (quantite < 0) {
            throw new Exception("Quantite insuffisante");
        }
        this.quantite = quantite;
    }
    public void setQuantiteString(String quantite_string) {
        
    }
}
