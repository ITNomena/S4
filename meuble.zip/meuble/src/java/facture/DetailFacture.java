/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facture;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import connection.MyConnection;
import meuble.Meuble;

/**
 *
 * @author 1
 */
public class DetailFacture {
    public int idDetailFacture;
    public Facture facture;
    public Meuble meuble;
    public int quantite;

    public DetailFacture() {

    }

    public DetailFacture(Facture facture, Meuble meuble,int quantite) {
        this.setFacture(facture);
        this.setMeuble(meuble);
        this.setQuantite(quantite);
    }

    public DetailFacture(int idDetailFacture,Facture facture, Meuble meuble,int quantite) {
        this.setIdDetailFacture(idDetailFacture);
        this.setFacture(facture);
        this.setMeuble(meuble);
        this.setQuantite(quantite);
    }


    public void insertDetailFacture(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into detailfacture(idfacture,idmeuble,quantite) values ("+this.getFacture().getIdFacture()+","+this.getMeuble().getIdMeuble()+","+this.getQuantite()+")";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            // int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public int getIdDetailFacture() {
        return idDetailFacture;
    }
    public void setIdDetailFacture(int idDetailFacture) {
        this.idDetailFacture = idDetailFacture;
    }
    public Facture getFacture() {
        return facture;
    }
    public void setFacture(Facture facture) {
        this.facture = facture;
    }
    public Meuble getMeuble() {
        return meuble;
    }
    public void setMeuble(Meuble meuble) {
        this.meuble = meuble;
    }
    public int getQuantite() {
        return quantite;
    }
    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

}
