/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facture;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import client.Client;
import connection.MyConnection;

/**
 *
 * @author 1
 */
public class Facture {
    public int idFacture;
    public Date dateFacture;
    public Client client;
    public String ref;

    public Facture() {

    }

    public Facture(Client client,String ref) {
        this.setClient(client);
        this.setRef(ref);
    }

    public Facture(int idFacture, Date dateFacture, Client client, String ref) {
        this.setIdFacture(idFacture);
        this.setDateFacture(dateFacture);
        this.setClient(client);
        this.setRef(ref);
    }

    public Facture getFatctureById(Connection connect, int idFacture) throws Exception {
        Facture facture = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from facture where idfacture="+idFacture;
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Client cl = new Client();
            cl.setIdClient(rs.getInt("idFacture"));

            facture = new Facture(rs.getInt("idFacture"),rs.getDate("datefacture"), client, rs.getString("ref"));

        }
        rs.close();
        st.close();
        connect.close();

        return facture;
    }

    public ArrayList<Facture> getAllFacture(Connection connect) throws Exception {
        ArrayList<Facture> list_facture = new ArrayList<Facture>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from facture";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Client cl = new Client();
            cl.setIdClient(rs.getInt("idFacture"));

            Facture facture = new Facture(rs.getInt("idFacture"),rs.getDate("datefacture"), client, rs.getString("ref"));

            list_facture.add(facture);
        }
        rs.close();
        st.close();
        connect.close();

        return list_facture;
    }
    

    public void insertFacture(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into facture(datefacture,idclient,ref) values (CURRENT_DATE,"+this.getClient().getIdClient()+",'"+this.getRef()+"')";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            // int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public int getIdFacture() {
        return idFacture;
    }
    public void setIdFacture(int idFacture) {
        this.idFacture = idFacture;
    }
    public Date getDateFacture() {
        return dateFacture;
    }
    public void setDateFacture(Date dateFacture) {
        this.dateFacture = dateFacture;
    }
    public Client getClient() {
        return client;
    }
    public void setClient(Client client) {
        this.client = client;
    }
    public String getRef() {
        return ref;
    }
    public void setRef(String ref) {
        this.ref = ref;
    }
}
