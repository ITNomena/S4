/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package meuble;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import categorie.Categorie;
import connection.MyConnection;
import matiere.Matiere;
import style.Styles;
import volume.Volume;

/**
 *
 * @author 1
 */
public class Meuble {
    int idMeuble;
    String nom;
    Categorie categorie;
    Styles styles;
    Volume volume;

    public Meuble() {

    }

    public Meuble(String nom,Categorie categorie,Styles styles,Volume volume) {
        this.setNom(nom);
        this.setCategorie(categorie);
        this.setStyles(styles);
        this.setVolume(volume);
    }

    public Meuble(int idMeuble,String nom,Categorie categorie,Styles styles,Volume volume) {
        this.setIdMeuble(idMeuble);
        this.setNom(nom);
        this.setCategorie(categorie);
        this.setStyles(styles);
        this.setVolume(volume);
    }

    public ArrayList<Meuble> getListMeuble(Connection connect) throws Exception {
        ArrayList<Meuble> meuble = new ArrayList<Meuble>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select meuble.nom,categorie.nom as categorie,style.nom as style,volume.types as volume from meuble join categorie on categorie.idcategorie=meuble.idcategorie join style on style.idstyle=meuble.idstyle join volume on volume.idvolume=meuble.idvolume";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Categorie c = new Categorie();
            c.setnom(rs.getString("categorie"));

            Styles stl = new Styles();
            stl.setnom(rs.getString("style"));

            Volume v = new Volume();
            v.settypes(rs.getString("volume"));

            Meuble m = new Meuble(rs.getString("nom"),c,stl,v);
            meuble.add(m);
        }
        rs.close();
        st.close();
        connect.close();

        return meuble;
    }

    public ArrayList<Meuble> getAllMeuble(Connection connect) throws Exception {
        ArrayList<Meuble> meuble = new ArrayList<Meuble>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        Statement st = connect.createStatement();
        String query ="select * from meuble";
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Categorie c = new Categorie();
            c.setidCategorie(rs.getInt("idcategorie"));

            Styles stl = new Styles();
            stl.setidStyle(rs.getInt("idstyle"));

            Volume v = new Volume();
            v.setidVolume(rs.getInt("idvolume"));

            Meuble m = new Meuble(rs.getInt("idmeuble"),rs.getString("nom"),c,stl,v);
            meuble.add(m);
        }
        rs.close();
        st.close();
        connect.close();

        return meuble;
    }

    public void insertMeuble(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into fabrication(nom,idCategorie,idstyle,idvolume) values('"+this.getNom()+"',"+this.getCategorie().getidCategorie()+","+this.getStyles().getidStyle()+","+this.getVolume().getidVolume()+")";
        System.out.println(query);
        Connection conn=MyConnection.connexion("postgres");
        try{
            PreparedStatement ps = conn.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdMeuble() {
        return idMeuble;
    }
    public void setIdMeuble(int idMeuble) {
        this.idMeuble = idMeuble;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public Categorie getCategorie() {
        return categorie;
    }
    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }
    public Styles getStyles() {
        return styles;
    }
    public void setStyles(Styles styles) {
        this.styles = styles;
    }
    public Volume getVolume() {
        return volume;
    }
    public void setVolume(Volume volume) {
        this.volume = volume;
    }
}
