/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package meuble;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;

/**
 *
 * @author 1
 */
public class PrixVente {
    public int idPrixVente;
    public Meuble meuble;
    public double prix;

    public PrixVente() {

    }

    public PrixVente(Meuble meuble,double prix) {
        this.setMeuble(meuble);
        this.setPrix(prix);
    }

    public PrixVente(int idPrixVente,Meuble meuble,double prix) {
        this.setIdPrixVente(idPrixVente);
        this.setMeuble(meuble);
        this.setPrix(prix);
    }

    public ArrayList<PrixVente> getAllPrixVente(Connection connect)throws Exception {
        ArrayList<PrixVente> listPrixVente = new ArrayList<PrixVente>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select meuble.idmeuble,meuble.nom,prix_vente.prix from prix_vente join meuble on meuble.idmeuble=prix_vente.idmeuble";
        System.out.println(query);
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Meuble m = new Meuble();
            m.setIdMeuble(rs.getInt("idmeuble"));
            m.setNom(rs.getString("nom"));

            PrixVente PrixVente = new PrixVente();
            PrixVente.setMeuble(m);
            PrixVente.setPrix(rs.getDouble("prix"));

            listPrixVente.add(PrixVente);
            
        }
        rs.close();
        st.close();
        connect.close();

        return listPrixVente;
    }

    public void insertPrixVente(Connection connect)throws Exception{
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }
        String query="insert into prix_vente(idmeuble,prix) values ("+this.getMeuble().getIdMeuble()+","+this.getPrix()+")";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    public int getIdPrixVente() {
        return idPrixVente;
    }
    public void setIdPrixVente(int idPrixVente) {
        this.idPrixVente = idPrixVente;
    }
    public Meuble getMeuble() {
        return meuble;
    }
    public void setMeuble(Meuble meuble) {
        this.meuble = meuble;
    }
    public double getPrix() {
        return prix;
    }
    public void setPrix(double prix) {
        this.prix = prix;
    }
}
