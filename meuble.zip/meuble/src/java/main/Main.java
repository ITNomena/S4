/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;
import matiere.MatiereStyle;
import meuble.Meuble;
import poste.PosteFabrication;
import stock.StockMatiere;
import matiere.Matiere;
import connection.*;
import facture.DetailFacture;
import facture.Facture;

import java.sql.*;
import java.util.ArrayList;
import affichage.*;
import categorie.*;
import client.Client;
import style.*;
import vente.Vente;
import volume.*;

/**
 *
 * @author itu
 */
public class Main {
    public static void main(String[]args) throws Exception{
        try{
            // Matiere materiel=new Matiere("metal");
            // materiel.setidMatiere(1);

            // Categorie categorie=new Categorie();
            // categorie.setidCategorie(1);

            // Styles style=new Styles();
            // style.setidStyle(2);

            // MatiereStyle ms = new MatiereStyle(style,materiel);
            
            // materiel.insertMateriel(null);
            // ms.insertMatiere_style(null);
            // MaterielStyle ms=new MaterielStyle();
            // ArrayList<ListeMateriel> lm=ms.getMaterielByStyle(null,"1");
            // for(int i=0;i<lm.size();i++){
            //     System.out.println(lm.get(i).getmateriels());

            // Styles style = new Styles();
            // ArrayList<Styles> list_style = style.getAllStyle(null);
            // for (int i = 0; i < list_style.size(); i++) {
            //     System.out.println(list_style.get(i).getnom());
            // }

            //  StockMatiere stockMatiere = new StockMatiere();
            //  stockMatiere.updateStockMatiere(null, 1, 6);

            // PosteFabrication posteFabrication = new PosteFabrication();
            // posteFabrication.insertPosteFabrication(null, 1);

            // Client client = new Client("RASAMISOA","Mahefa");
            // client.insertClient(null);
            // client.setIdClient(1);

            // Facture facture = new Facture(client,"ref1");
            // facture.insertFacture(null);
            // facture.setIdFacture(1);

            // Meuble meuble = new Meuble();
            // meuble.setIdMeuble(1);

            // DetailFacture detailFacture = new DetailFacture(facture,meuble,2);
            // detailFacture.insertDetailFacture(null);

            Vente v = new Vente().getMeubleRestantByIdMeuble(null,2, 2);
            }
            catch(Exception e){
                e.printStackTrace();
            }
    }
}
