﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace App_ML_mail.Models;

[Table("utilisateur")]
public partial class Utilisateur
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("nom")]
    [StringLength(100)]
    public string Nom { get; set; } = null!;

    [InverseProperty("IduserenvoiNavigation")]
    public virtual ICollection<Mail> MailIduserenvoiNavigations { get; set; } = new List<Mail>();

    [InverseProperty("IduserrecuNavigation")]
    public virtual ICollection<Mail> MailIduserrecuNavigations { get; set; } = new List<Mail>();
}
