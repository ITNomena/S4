﻿using System.Diagnostics;

namespace App_ML_mail;

public class ShellCommandExecutor
{

    public static string ExecuteZshCommand(string command)
    {
        var processStartInfo = new ProcessStartInfo
        {
            FileName = "/bin/zsh",
            Arguments = "-c \"" + command + "\"",
            RedirectStandardOutput = true,
            UseShellExecute = false,
            CreateNoWindow = true,
        };

        var process = new Process
        {
            StartInfo = processStartInfo,
        };

        process.Start();
        string result = process.StandardOutput.ReadToEnd();
        process.WaitForExit();

        return result;
    }

    public static string ExecutePythonScript(string scriptPath, string args)
    {
        ProcessStartInfo startInfo = new ProcessStartInfo();
        startInfo.FileName = "/usr/local/bin/python3";
        string argWithQuotes = $"\"{args}\""; // Ajoute des guillemets autour de args
        startInfo.Arguments = $"{scriptPath} {argWithQuotes}";

        startInfo.UseShellExecute = false;
        startInfo.RedirectStandardOutput = true;
        startInfo.RedirectStandardError = true;

        string result = string.Empty;
        string error = string.Empty;

        using (Process process = Process.Start(startInfo))
        {
            using (StreamReader reader = process.StandardOutput)
            {
                result = reader.ReadToEnd();
            }

            using (StreamReader errorReader = process.StandardError)
            {
                error = errorReader.ReadToEnd();
            }
        }

        string processedResult = ProcessResult(result, error);
        return processedResult;
    }

    private static string ProcessResult(string output, string error)
    {
        string result = string.Empty;

        if (!string.IsNullOrEmpty(output))
        {
            result = output.Trim();    // Remove any leading/trailing white spaces
        }

        if (!string.IsNullOrEmpty(error))
        {
            result += "Error: " + error;
        }

        return result;
    }
}
