﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace App_ML_mail.Models;

[Table("mail")]
public partial class Mail
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("iduserenvoi")]
    public int Iduserenvoi { get; set; }

    [Column("iduserrecu")]
    public int Iduserrecu { get; set; }

    [Column("idmailprecedent")]
    public int? Idmailprecedent { get; set; }

    [Column("classe_mail")]
    public int ClasseMail { get; set; }

    [Column("texte")]
    public string Texte { get; set; } = null!;

    [Column("estlu")]
    public int Estlu { get; set; }

    [Column("estdansmodel")]
    public int Estdansmodel { get; set; }

    [Column("dateenvoi", TypeName = "timestamp without time zone")]
    public DateTime? Dateenvoi { get; set; }

    [ForeignKey("Idmailprecedent")]
    [InverseProperty("InverseIdmailprecedentNavigation")]
    public virtual Mail? IdmailprecedentNavigation { get; set; }

    [ForeignKey("Iduserenvoi")]
    [InverseProperty("MailIduserenvoiNavigations")]
    public virtual Utilisateur IduserenvoiNavigation { get; set; } = null!;

    [ForeignKey("Iduserrecu")]
    [InverseProperty("MailIduserrecuNavigations")]
    public virtual Utilisateur IduserrecuNavigation { get; set; } = null!;

    [InverseProperty("IdmailprecedentNavigation")]
    public virtual ICollection<Mail> InverseIdmailprecedentNavigation { get; set; } = new List<Mail>();


    public string GetEtatLuStr() {
        if (Estlu == 0)
            return "Non";
        if (Estlu == 1)
            return "Oui";
        else
            return "Etat non défini";
    }

    public string GetEtatModelStr()
    {
        if (Estdansmodel == 0)
            return "Absent";
        if (Estdansmodel == 1)
            return "Présent";
        else
            return "Etat non défini";
    }

    public string GetClasseMailStr()
    {
        if (ClasseMail == 0)
            return "Normal";
        if (ClasseMail == 1)
            return "Spam";
        else
            return "Classe non définie";
    }


}
