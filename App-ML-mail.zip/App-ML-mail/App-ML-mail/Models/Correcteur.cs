﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace App_ML_mail.Models
{
	public class Correcteur
	{
		public Correcteur()
		{
		}

        public static int DamerauLevenshteinDistance(string str1, string str2)
        {
            str1 = str1.ToLower();
            str2 = str2.ToLower();

            var d = new int[str1.Length + 1, str2.Length + 1];

            for (int i = 0; i <= str1.Length; i++)
                d[i, 0] = i;

            for (int j = 0; j <= str2.Length; j++)
                d[0, j] = j;

            for (int i = 1; i <= str1.Length; i++)
            {
                for (int j = 1; j <= str2.Length; j++)
                {
                    int cost = str1[i - 1] == str2[j - 1] ? 0 : 1;

                    d[i, j] = Math.Min(
                        Math.Min(
                            d[i - 1, j] + 1,       // suppression
                            d[i, j - 1] + 1),      // insertion
                        d[i - 1, j - 1] + cost);   // substitution

                    if (i > 1 && j > 1
                        && str1[i - 1] == str2[j - 2]
                        && str1[i - 2] == str2[j - 1])
                    {
                        d[i, j] = Math.Min(
                            d[i, j],
                            d[i - 2, j - 2] + cost // transposition
                        );
                    }
                }
            }
            return d[str1.Length, str2.Length];
        }

        /*
        public static string CorrectMot(string pathDico, string word)
        {
            var dictionary = File.ReadAllLines(pathDico);
            string closest = word;
            int shortest = -1;

            foreach (var dictWord in dictionary)
            {
                int lev = DamerauLevenshteinDistance(word, dictWord);

                if (lev == 0)
                {
                    closest = dictWord;
                    shortest = 0;
                    break;
                }

                if (lev < shortest || shortest < 0)
                {
                    closest = dictWord;
                    shortest = lev;
                }
            }

            return closest;
        }


        public static string ToUpperFirstChar(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return string.Empty;
            }
            return $"{input[0].ToString().ToUpper()}{input.Substring(1)}";
        }


        public static string CorrectPhrase(string pathDico, string sentence)
        {
            // Using a regular expression to split the sentence into tokens that include words, punctuation, and numbers.
            var tokens = Regex.Split(sentence, @"(\W+)");

            // For each token, check if it is a word. If it is, apply the CorrectMot function. Otherwise, leave it unchanged.
            for (var i = 0; i < tokens.Length; i++)
            {
                if (Regex.IsMatch(tokens[i], @"^[a-zA-Z]+$"))
                    tokens[i] = CorrectMot(pathDico, tokens[i]);
            }

            if (Regex.IsMatch(tokens[0], @"^[a-zA-Z]+$"))
                tokens[0] = ToUpperFirstChar(tokens[0]);

            // Combine the tokens back into a sentence.
            var correctedSentence = string.Join("", tokens);

            return correctedSentence;
        }
        */


        /// <summary>
        /// Liste
        /// </summary>
        /// <param name="pathDico"></param>
        /// <param name="word"></param>
        /// <param name="count"> le nombre de mots maximum avec la même valeur DamerauLevenshteinDistance</param>
        /// <param name="maxLen"> le nombre maximum </param>
        /// <returns></returns>
        public static List<KeyValuePair<int, List<string>>> MotsProches(string pathDico, string word, int count, int maxLen)
        {
            var dictionary = File.ReadAllLines(pathDico);
            var closestWords = new SortedList<int, List<string>>();

            foreach (var dictWord in dictionary)
            {
                int lev = DamerauLevenshteinDistance(word, dictWord);

                if (!closestWords.ContainsKey(lev))
                {
                    closestWords[lev] = new List<string>() { dictWord };
                }
                else if (closestWords[lev].Count < count)  
                {
                    closestWords[lev].Add(dictWord);
                }
                else if (lev < closestWords.Keys[closestWords.Count - 1])
                {
                    int lastKey = closestWords.Keys[closestWords.Count - 1];

                    if (closestWords[lastKey].Count >= count)
                    {
                        closestWords.Remove(lastKey);
                    }
                    
                    if (!closestWords.ContainsKey(lev)) 
                    {
                        closestWords[lev] = new List<string>() { dictWord };
                    }
                }
            }

            return closestWords.Take(maxLen).ToList();
        }

        public static List<List<KeyValuePair<int, List<string>>>> MotsProchesPhrase(string pathDico, string phrase, int count, int maxLevValue)
        {
            if (phrase == null)
                throw new Exception("Phrase nulle");

            var resultat = new List<List<KeyValuePair<int, List<string>>>>();

            // Using a regular expression to split the sentence into tokens that include words, punctuation, and numbers.
            var tokens = Regex.Split(phrase, @"(\W+)");

            foreach(string token in tokens)
                if (Regex.IsMatch(token, @"^[a-zA-Z]+$"))
                   resultat.Add(MotsProches(pathDico, token, count, maxLevValue));

            return resultat;
        }
    }
}

