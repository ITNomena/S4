﻿using App_ML_mail.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;



namespace App_ML_mail.Pages.Login
{
	public class IndexModel : PageModel
    {
        private readonly Data.MailDbContext _context;
        public string mess = "";

        public IndexModel(Data.MailDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            //mess = Correcteur.CorrectPhrase("Data/liste_mots_francais.txt", "obnjuor à vous, j'ia 19 nas !");

            //var test = Correcteur.MotsProchesPhrase("Data/liste_mots_francais.txt", "obnjour, lse asit 88", 4, 3);

            //mess = Correcteur.MotsProches("Data/liste_mots_francais.txt", "obnjuor", 2, 2).ToString();
            //mess = ShellCommandExecutor.ExecuteCommand("ls");

            ViewData["Iduser"] = new SelectList(_context.Utilisateurs, "Id", "Nom");
            return Page();

        }

        public IActionResult OnPost()
        {

            _ = int.TryParse(Request.Form["iduser"], out int iduser);
            HttpContext.Session.SetInt32("iduser", iduser);

            return RedirectToPage("Boite_reception/Index");
        }

    }
}
