using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using App_ML_mail.Data;
using App_ML_mail.Models;

namespace App_ML_mail.Pages.Boite_reception
{
    public class DetailsModel : PageModel
    {
        private readonly App_ML_mail.Data.MailDbContext _context;

        public DetailsModel(App_ML_mail.Data.MailDbContext context)
        {
            _context = context;
        }

      public Mail Mail { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Mail == null)
            {
                return NotFound();
            }

            var mail = await _context.Mail.FirstOrDefaultAsync(m => m.Id == id);
            if (mail == null)
            {
                return NotFound();
            }
            else 
            {
                Mail = mail;
            }
            return Page();
        }
    }
}
