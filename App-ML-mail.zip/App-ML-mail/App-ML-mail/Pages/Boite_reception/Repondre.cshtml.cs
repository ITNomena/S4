using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using App_ML_mail.Data;
using App_ML_mail.Models;
using Microsoft.EntityFrameworkCore;

namespace App_ML_mail.Pages.Boite_reception
{

    public class RepondreModel : PageModel
    {
        private readonly App_ML_mail.Data.MailDbContext _context;
        public Mail? mail { get; set; }
        public Utilisateur? user;

        public RepondreModel(App_ML_mail.Data.MailDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet(int idmail)
        {
            if(HttpContext.Session.GetInt32("iduser")==null)
                return RedirectToPage("../Index");


            if (_context.Utilisateurs != null)
                user = _context.Utilisateurs.Find((int)HttpContext.Session.GetInt32("iduser"));

            mail = _context.Mail
                   .Include(m => m.IduserrecuNavigation)
                   .Include(m => m.IduserenvoiNavigation)
                   .FirstOrDefault(item => item.Id == idmail);

            if (mail==null)
                return RedirectToPage("./Index");

            return Page();
        }

        [BindProperty]
        public Mail Mail { get; set; } = default!;


        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (_context.Mail == null || Mail == null)
            {
                return Page();
            }

            if (HttpContext.Session.GetInt32("iduser") == null)
                return RedirectToPage("/Index");

            Mail.Iduserenvoi = (int)HttpContext.Session.GetInt32("iduser");

            string scriptPath = "/Users/nomena/Projects/App-ML-mail/App-ML-mail/script.py";
            string arg = Mail.Texte;

            string res = ShellCommandExecutor.ExecutePythonScript(scriptPath, arg);

            int.TryParse(res, out int resultat);
            Mail.ClasseMail = resultat;

            _context.Mail.Add(Mail);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
