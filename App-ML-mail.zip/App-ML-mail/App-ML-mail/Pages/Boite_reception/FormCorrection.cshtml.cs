﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using App_ML_mail.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static System.Net.Mime.MediaTypeNames;

namespace App_ML_mail.Pages.Boite_reception
{
	public class CorrecteurModel : PageModel
    {

        public PageResult OnGet() {
            return Page();
        }


        public RedirectToPageResult OnPost() {
            var text = Request.Form["textToCorrect"];
            return RedirectToPage("./Correction", new { text });
        }
    }
}
