using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using App_ML_mail.Data;
using App_ML_mail.Models;

namespace App_ML_mail.Pages.Boite_reception
{
    public class EnvoyésModel : PageModel
    {
        private readonly App_ML_mail.Data.MailDbContext _context;
        private int? iduser;
        public Utilisateur? user;

        public EnvoyésModel(App_ML_mail.Data.MailDbContext context)
        {
            _context = context;
        }

        public IList<Mail> Mail { get;set; } = default!;

        public ActionResult OnGet()
        {

            if (HttpContext.Session.GetInt32("iduser") == null)
                return RedirectToPage("/Index");


            iduser = HttpContext.Session.GetInt32("iduser");

            // mails envoyés
            if (iduser is not null)
            {

                if (_context.Utilisateurs != null)
                    user = _context.Utilisateurs.Find(iduser);
                else
                    return RedirectToPage("./Index");

                if (_context.Mail != null)
                {

                        Mail = _context.Mail
                                    .Include(m => m.IdmailprecedentNavigation)
                                    .Include(m => m.IduserenvoiNavigation)
                                    .Include(m => m.IduserrecuNavigation)
                                    .Where(m => m.IduserenvoiNavigation.Id == iduser)
                                    .ToList();
                }
            }

            return Page();

        }



    }
}
