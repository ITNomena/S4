﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App_ML_mail.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace App_ML_mail.Pages.Boite_reception
{
	public class MarquerLuModel : PageModel
    {
        private readonly App_ML_mail.Data.MailDbContext _context;

        public MarquerLuModel(App_ML_mail.Data.MailDbContext context)
        {
            _context = context;
        }

        public RedirectToPageResult OnGet(int idmail, int? isSpam)
        {

                Mail? entity = _context.Mail.FirstOrDefault(item => item.Id == idmail);

                // Validate entity is not null
                if (entity != null)
                {
                    // Make changes on entity
                    entity.Estlu = 1;

                if (isSpam != null)
                    if(isSpam ==1)
                        entity.ClasseMail = 1;
                    else
                        entity.ClasseMail = 0;

                // Save changes in database
                _context.SaveChanges();
                
                }

            return RedirectToPage("./Index");

        }
    }
}
