﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using App_ML_mail.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace App_ML_mail.Pages.Boite_reception
{
    public class CorrectionModel : PageModel
    {
        public List<List<KeyValuePair<int, List<string>>>>? correction;
        public string test;
        public List<string> mots;

        public PageResult OnGet(string text)
        {
            correction = Correcteur.MotsProchesPhrase("Data/liste_mots_francais.txt", text, 4, 3);
            test = text;

            // Using a regular expression to split the sentence into tokens that include words, punctuation, and numbers.
            var tokens = Regex.Split(text, @"(\W+)");

            mots = new();
            foreach (string token in tokens)
                if (Regex.IsMatch(token, @"^[a-zA-Z]+$"))
                    mots.Add(token);

            return Page();
        }

    }
}
