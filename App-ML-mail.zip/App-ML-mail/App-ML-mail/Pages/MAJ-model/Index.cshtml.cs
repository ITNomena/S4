﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using App_ML_mail.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace App_ML_mail.Pages.MAJmodel
{
	public class IndexModel : PageModel
    {
        private readonly Data.MailDbContext _context;

        public string? outputPsql;
        public string? outputCat;
        public string? outputRm;
        public string? outputMajModel;

        public IndexModel(Data.MailDbContext context)
        {
            _context = context;
        }
        public PageResult OnGet()
        {
            // MAJ DATA CSV
            string command = "/Applications/Postgres.app/Contents/Versions/latest/bin/psql -U nomena -d mail_db -c '\\copy (select classe_mail, texte from mail where estdansmodel = 0) to /Users/nomena/Projects/App-ML-mail/App-ML-mail/mail-data/temp.csv with csv'";
            outputPsql = ShellCommandExecutor.ExecuteZshCommand(command);

            var mails = _context.Mail.Where(m => m.Estdansmodel == 0);
            foreach (var mail in mails)
            {
                mail.Estdansmodel = 1;
            }
            _context.SaveChanges();

            string command1 = "cat '/Users/nomena/Projects/App-ML-mail/App-ML-mail/mail-data/temp.csv' >> /Users/nomena/Projects/App-ML-mail/App-ML-mail/mail-data/mail-all.csv";
            outputCat = ShellCommandExecutor.ExecuteZshCommand(command1);

            command = "rm /Users/nomena/Projects/App-ML-mail/App-ML-mail/mail-data/temp.csv";
            outputRm = ShellCommandExecutor.ExecuteZshCommand(command);

            // MAJ MODELE PYTHON
            string scriptPath = "/Users/nomena/Projects/App-ML-mail/App-ML-mail/maj-model.py";
            outputMajModel = ShellCommandExecutor.ExecutePythonScript(scriptPath, "");


            return Page();

        }
    }
}
