using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using App_ML_mail.Data;
using App_ML_mail.Models;

namespace App_ML_mail.Pages.Utilisateur_gestion
{
    public class CreateModel : PageModel
    {
        private readonly App_ML_mail.Data.MailDbContext _context;

        public CreateModel(App_ML_mail.Data.MailDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Utilisateur Utilisateur { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.Utilisateurs == null || Utilisateur == null)
            {
                return Page();
            }

            _context.Utilisateurs.Add(Utilisateur);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
