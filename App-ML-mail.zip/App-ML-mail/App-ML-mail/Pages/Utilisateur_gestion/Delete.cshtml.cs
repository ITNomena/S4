using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using App_ML_mail.Data;
using App_ML_mail.Models;

namespace App_ML_mail.Pages.Utilisateur_gestion
{
    public class DeleteModel : PageModel
    {
        private readonly App_ML_mail.Data.MailDbContext _context;

        public DeleteModel(App_ML_mail.Data.MailDbContext context)
        {
            _context = context;
        }

        [BindProperty]
      public Utilisateur Utilisateur { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Utilisateurs == null)
            {
                return NotFound();
            }

            var utilisateur = await _context.Utilisateurs.FirstOrDefaultAsync(m => m.Id == id);

            if (utilisateur == null)
            {
                return NotFound();
            }
            else 
            {
                Utilisateur = utilisateur;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.Utilisateurs == null)
            {
                return NotFound();
            }
            var utilisateur = await _context.Utilisateurs.FindAsync(id);

            if (utilisateur != null)
            {
                Utilisateur = utilisateur;
                _context.Utilisateurs.Remove(Utilisateur);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
