﻿using System;
using System.Collections.Generic;
using App_ML_mail.Models;
using Microsoft.EntityFrameworkCore;

namespace App_ML_mail.Data;

public partial class MailDbContext : DbContext
{
    public MailDbContext()
    {
    }

    public MailDbContext(DbContextOptions<MailDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Mail> Mail { get; set; }

    public virtual DbSet<Utilisateur> Utilisateurs { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Mail>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("mail_pkey");

            entity.Property(e => e.Dateenvoi).HasDefaultValueSql("now()");

            entity.HasOne(d => d.IdmailprecedentNavigation).WithMany(p => p.InverseIdmailprecedentNavigation).HasConstraintName("mail_idmailprecedent_fkey");

            entity.HasOne(d => d.IduserenvoiNavigation).WithMany(p => p.MailIduserenvoiNavigations)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("mail_iduserenvoi_fkey");

            entity.HasOne(d => d.IduserrecuNavigation).WithMany(p => p.MailIduserrecuNavigations)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("mail_iduserrecu_fkey");
        });

        modelBuilder.Entity<Utilisateur>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("utilisateur_pkey");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
