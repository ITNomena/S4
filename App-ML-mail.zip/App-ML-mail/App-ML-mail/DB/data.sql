﻿--database : mail_db
--user : nomena
--password : root
--connection string :  "MailContext": "Host=localhost; Database=mail_db; Username=nomena; Password=root;"

/*
Scaffolding :

dotnet ef dbcontext scaffold "Name=ConnectionStrings:MailContext" Npgsql.EntityFrameworkCore.PostgreSQL --context-dir Data --output-dir Models --data-annotations

*/

create table utilisateur(
    id serial primary key,
    nom varchar(100) not null
);
/*
insert into utilisateur values(default, 'user1');
insert into utilisateur values(default, 'user2');
insert into utilisateur values(default, 'user3');
*/

create table mail(
    id serial primary key,
    iduserEnvoi int not null,
    iduserRecu int not null,
    idmailprecedent int default null,
    classe_mail int default 0 not null, -- 0 normal, 1 spam
    texte text not null,
    estlu int default 0 not null, -- 0 non-lu, 1 lu
    estdansmodel int default 0 not null, -- 0 non, 1 oui
    dateEnvoi timestamp default now(),
    foreign key (iduserenvoi) references utilisateur(id),
    foreign key (iduserRecu) references utilisateur(id),
    foreign key (idmailprecedent) references mail(id)
);
/*

--normaux
insert into mail values(default, 1, 2, null, 0, 'Ceci est un simple mail de test, tout va à merveille', 0, 0, default);
insert into mail values(default, 2, 1, 1, 0, 'Bien recu, compris', 1, 0, default);

--spam
insert into mail values(default, 3, 1, null, 1, 'Devenez le plus beau de la Terre grace à ce produit non-dopant. Cliquez ici !' , 1, 1, default);
insert into mail values(default, 3, 2, null, 1, 'Devenez le plus beau de la Terre grace à ce produit non-dopant. Cliquez ici !', 0, 0, default);

*/