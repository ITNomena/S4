﻿using App_ML_mail.Data;
using Microsoft.EntityFrameworkCore;


var builder = WebApplication.CreateBuilder(args);


// Add services to the container.
builder.Services.AddRazorPages();

builder.Services.AddDbContext<MailDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("MailContext") ?? throw new InvalidOperationException("Connection string 'MailContext' not found.")));

// Enable session usage
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Enable session usage
app.UseSession();

app.UseAuthorization();

app.MapRazorPages();

app.Run();
