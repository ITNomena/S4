---ordinateur
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,1);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,2);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,3);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,6);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,10);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,15);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,16);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,17);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,18);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,19);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,20);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,21);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,22);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,53);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,54);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(1,55);


INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(2,1);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(2,2);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(2,65);

INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(3,1);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(3,2);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(3,56);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(3,57);

INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(4,3);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(4,6);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(4,10);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(4,17);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(4,18);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(4,19);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(4,53);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(4,54);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(4,55);


INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(5,1);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(5,2);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(5,6);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(5,17);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(5,64);

INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,1);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,2);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,5);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,7);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,8);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,9);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,11);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,12);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,13);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,14);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,23);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,24);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,25);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,26);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,29);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,30);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,31);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,32);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,33);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,34);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,35);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,36);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,37);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,38);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,39);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,40);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,41);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,42);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,43);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,44);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,45);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,46);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,47);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,48);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,49);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,50);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,51);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,52);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,58);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(6,59);


INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,1);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,2);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,7);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,8);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,11);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,14);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,23);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,25);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,30);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,31);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,34);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,35);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,36);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,37);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,38);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,39);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,40);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,41);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,42);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,45);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,46);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,50);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,52);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,54);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(7,58);

INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,1);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,2);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,8);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,11);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,13);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,27);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,28);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,31);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,35);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,36);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,37);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,39);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,41);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,42);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,43);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,50);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(8,58);


INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,1);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,2);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,5);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,6);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,7);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,8);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,9);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,11);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,12);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,23);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,24);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,25);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,26);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,29);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,30);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,31);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,32);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,33);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,34);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,35);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,36);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,37);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,38);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,39);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,40);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,41);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,42);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,46);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,50);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,52);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,58);
INSERT INTO ActionImmobilisation (idSousCategorie, idActionDetail)VALUES(9,59);







