/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proforma;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import article.Article;
import connection.MyConnection;
import fournisseur.Fournisseur;

/**
 *
 * @author 1
 */
public class DetailProforma {
    public int idDetailProforma;
    public Proforma proforma;
    public Article article;
    public int quantite;
    public double prix_unitaire;
    public Date date_livraison;

    public String date_livraison_string;

    public DetailProforma() {

    }

    public DetailProforma(Proforma proforma,Article article,int quantite,double prix_unitaire,Date date_livraison) {
        this.setProforma(proforma);
        this.setArticle(article);
        this.setQuantite(quantite);
        this.setPrix_unitaire(prix_unitaire);
        this.setDate_livraison(date_livraison);
    }

    public DetailProforma(Proforma proforma,Article article,int quantite,double prix_unitaire,String date_livraison) {
        this.setProforma(proforma);
        this.setArticle(article);
        this.setQuantite(quantite);
        this.setPrix_unitaire(prix_unitaire);
        this.setDate_livraison_string(date_livraison);
    }

    public DetailProforma(int idDetailProforma,Proforma proforma,Article article,int quantite,double prix_unitaire,Date date_livraison) {
        this.setIdDetailProforma(idDetailProforma);
        this.setProforma(proforma);
        this.setArticle(article);
        this.setQuantite(quantite);
        this.setPrix_unitaire(prix_unitaire);
        this.setDate_livraison(date_livraison);
    }

    public DetailProforma getDetailProformaByIdProforma(Connection connect,int idproforma) throws Exception {
        DetailProforma detailProforma = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select pr.date as date,fr.nom as fournisseur,art.nom as article,dp.quantite as quantite,dp.prix_unitaire as prix_unitaire,dp.date_livraison as date_livraison from detail_proforma as dp "+
                    "join proforma pr on pr.idproforma=dp.idproforma join fournisseur fr on fr.idfournisseur=pr.idfournisseur join article art on art.idarticle=dp.idarticle "+
                    "where dp.idproforma="+idproforma;
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Fournisseur fr = new Fournisseur();
            fr.setNom(rs.getString("fournisseur"));

            Proforma pr = new Proforma();
            pr.setDate(rs.getDate("date"));
            pr.setFournisseur(fr);

            Article art = new Article();
            art.setNom(rs.getString("article"));

            detailProforma= new DetailProforma(pr,art,rs.getInt("quantite"),rs.getDouble("prix_unitaire"),rs.getDate("date_livraison"));
        }

        rs.close();
        st.close();
        connect.close();

        return detailProforma;
    }

    public void insertDetailProforma(Connection connect)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into detail_proforma (idproforma,idarticle,quantite,prix_unitaire,date_livraison) values ("+this.getProforma().getIdProforma()+","+this.getArticle().getIdArticle()+","+this.getQuantite()+","+this.getPrix_unitaire()+",'"+this.getDate_livraison_string()+"')";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdDetailProforma() {
        return idDetailProforma;
    }
    public void setIdDetailProforma(int idDetailProforma) {
        this.idDetailProforma = idDetailProforma;
    }
    public Proforma getProforma() {
        return proforma;
    }
    public void setProforma(Proforma proforma) {
        this.proforma = proforma;
    }
    public Article getArticle() {
        return article;
    }
    public void setArticle(Article article) {
        this.article = article;
    }
    public int getQuantite() {
        return quantite;
    }
    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }
    public double getPrix_unitaire() {
        return prix_unitaire;
    }
    public void setPrix_unitaire(double prix_unitaire) {
        this.prix_unitaire = prix_unitaire;
    }
    public Date getDate_livraison() {
        return date_livraison;
    }
    public void setDate_livraison(Date date_livraison) {
        this.date_livraison = date_livraison;
    }
    public String getDate_livraison_string() {
        return date_livraison_string;
    }
    public void setDate_livraison_string(String date_livraison_string) {
        this.date_livraison_string = date_livraison_string;
    }
}
