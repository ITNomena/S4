/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proforma;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;
import fournisseur.Fournisseur;

/**
 *
 * @author 1
 */
public class Proforma {
    public int idProforma;;
    public Date date;
    public Fournisseur fournisseur;
    public String reference;

    public Proforma() {

    }

    public Proforma(Fournisseur fournisseur,String reference) {
        this.setFournisseur(fournisseur);
        this.setReference(reference);
    }
    
    public Proforma(Date date,Fournisseur fournisseur,String reference) {
        this.setDate(date);
        this.setFournisseur(fournisseur);
        this.setReference(reference);
    }

    public Proforma(int idProforma,Date date,Fournisseur fournisseur,String reference) {
        this.setIdProforma(idProforma);
        this.setDate(date);
        this.setFournisseur(fournisseur);
        this.setReference(reference);
    }

    public ArrayList<Proforma> getAllProforma(Connection connect) throws Exception {
        ArrayList<Proforma> list_proforma = new ArrayList<Proforma>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select proforma.idproforma,proforma.date,fournisseur.nom,proforma.reference from proforma join fournisseur on fournisseur.idfournisseur=proforma.idfournisseur";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Fournisseur f = new Fournisseur();
            f.setNom(rs.getString("nom"));

            Proforma proforma = new Proforma(rs.getInt("idproforma"), rs.getDate("date"),f,rs.getString("reference"));

            list_proforma.add(proforma);
        }
        rs.close();
        st.close();
        connect.close();

        return list_proforma;
    }

    public void insertProforma(Connection connect)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into proforma (date,idfournisseur,reference) values (CURRENT_DATE,"+this.getFournisseur().getIdFournisseur()+",'"+this.getReference()+"')";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdProforma() {
        return idProforma;
    }
    public void setIdProforma(int idProforma) {
        this.idProforma = idProforma;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public Fournisseur getFournisseur() {
        return fournisseur;
    }
    public void setFournisseur(Fournisseur fournisseur) {
        this.fournisseur = fournisseur;
    }
    public String getReference() {
        return reference;
    }
    public void setReference(String reference) {
        this.reference = reference;
    }   

}
