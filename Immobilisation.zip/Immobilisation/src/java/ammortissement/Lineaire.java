/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ammortissement;

import java.sql.Date;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import exercice.Exercice;
import pv.Reception;
import pv.Utilisation;

/**
 *
 * @author 1
 */
public class Lineaire {
    public String code;
    public Date date_utilisation;
    public double valeur;
    public double amm_cumule_debut_periode;
    public double dotation;
    public int taux;
    public double amm_cumule_fin_periode;
    public double VNC;

    public Lineaire() {

    }

    public Lineaire(String code,Date date_utilisation,double valeur,double amm_cumule_debut_periode,double dotation,int taux,double amm_cumule_fin_periode,double VNC) {
        this.setCode(code);
        this.setDate_utilisation(date_utilisation);
        this.setValeur(valeur);
        this.setAmm_cumule_debut_periode(amm_cumule_debut_periode);
        this.setDotation(dotation);
        this.setTaux(taux);
        this.setAmm_cumule_fin_periode(amm_cumule_fin_periode);
        this.setVNC(VNC);
    }

    public ArrayList<Lineaire> Amortissement(int idimmobilisation,int taux) throws Exception {
        ArrayList<Lineaire> amortissement = new ArrayList<Lineaire>();

        Utilisation util = new Utilisation().getUtilisationByIdImmobilisation(null, idimmobilisation);
        Exercice exercice = new Exercice().getExercice(null);

        double amm_debut_periode = this.getAmmortissementcumuledebutperiode(exercice.getDatedebut(), util.getDatepv_utilisation());

        double dotation_premiere_annee = this.calculdotationMemeAnnee(exercice.getDatedefin(), util.getDatepv_utilisation(), util.getImmobilisation().getPrix(), taux);
        double amm_fin_periode = this.getAmmortissementcumulefinperiode(amm_debut_periode, dotation_premiere_annee);
        double vnc_premiere_anne = this.getValeurNetComptable(util.getImmobilisation().getPrix(), amm_fin_periode);

        Lineaire lin = new Lineaire(util.getImmobilisation().getCode(), util.getDatepv_utilisation(), util.getImmobilisation().getPrix(), amm_debut_periode, dotation_premiere_annee, taux, amm_fin_periode, vnc_premiere_anne);
        amortissement.add(lin);

        Reception reception = new Reception().getReceptionByIdImmobilisation(null, idimmobilisation);

        for (int i = reception.getAnnee_amortissemnt()-1; i > 0; i--) {
            amm_debut_periode = amm_fin_periode;
            double dotation_restant = this.calculdotationPasMemeAnnee(util.getImmobilisation().getPrix(),taux);
            amm_fin_periode = this.getAmmortissementcumulefinperiode(amm_debut_periode, dotation_restant);
            double vnc_restant = this.getValeurNetComptable(vnc_premiere_anne,amm_fin_periode);

            if (vnc_restant < 0) {
                break;
            }

            Lineaire lineaire = new Lineaire(util.getImmobilisation().getCode(), util.getDatepv_utilisation(), util.getImmobilisation().getPrix(), amm_debut_periode, dotation_restant, taux, amm_fin_periode, vnc_restant);

            amortissement.add(lineaire);

            // dotation_premiere_annee = dotation_restant;
            vnc_premiere_anne = vnc_restant;
        }

        return amortissement;
    }


    public double getAmmortissementcumuledebutperiode(Date datedebutexercice,Date datefirstutilisation) {
        double ammortissementcumuledebutperiode = 0.0;
        Calendar calendarDebutExercice = Calendar.getInstance();
        calendarDebutExercice.setTime(datedebutexercice);

        Calendar calendarFirstUtilisation = Calendar.getInstance();
        calendarFirstUtilisation.setTime(datefirstutilisation);

        int yearDebutExercice = calendarDebutExercice.get(Calendar.YEAR);
        int yearFirstUtilisation = calendarFirstUtilisation.get(Calendar.YEAR);

        if(datedebutexercice.before(datefirstutilisation) && yearDebutExercice == yearFirstUtilisation) {
            ammortissementcumuledebutperiode = 0;
        }
        
        return ammortissementcumuledebutperiode;
    }

    public int calculAnnee(Date datefirstUtilisation) {
        int annee = 0;
        Calendar calendarFirstUtilisation = Calendar.getInstance();
        calendarFirstUtilisation.setTime(datefirstUtilisation);
        int yearFirstUtilisation = calendarFirstUtilisation.get(Calendar.YEAR);
        annee = yearFirstUtilisation;

        return annee;
    }

    public double calculdotationMemeAnnee(Date datefinexercice,Date datefirstUtilisation,double valeurbrute,double taux) {
        double dotation = 0;
        // Calculer la différence en millisecondes entre les deux dates
        long differenceEnMillisecondes = datefinexercice.getTime() - datefirstUtilisation.getTime();

        // Convertir la différence en jours
        long NBjour = TimeUnit.DAYS.convert(differenceEnMillisecondes, TimeUnit.MILLISECONDS);
        System.out.println("NBjour = "+NBjour);

        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("#.##",symbols);
        dotation = Double.parseDouble(df.format((NBjour*valeurbrute*(taux/100))/365));

        return dotation;
    }

    public double calculdotationPasMemeAnnee(double valeurbrute,double taux) {
        double dotation = 0;
        dotation = valeurbrute*(taux/100);
        return dotation;
    }

    public double getAmmortissementcumulefinperiode(double Ammortissementcumuledebutperiode, double dotation) {
        double Ammortissementcumulefinperiode = 0;
        Ammortissementcumulefinperiode = Ammortissementcumuledebutperiode + dotation;
        return Ammortissementcumulefinperiode;
    }

    public double getValeurNetComptable(double valeurbrute,double Ammortissementcumulefinperiode) {
        double ValeurNetComptable = 0;

        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("#.##",symbols);

        ValeurNetComptable = Double.parseDouble(df.format(valeurbrute-Ammortissementcumulefinperiode));
        return ValeurNetComptable;
    }


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getDate_utilisation() {
        return date_utilisation;
    }

    public void setDate_utilisation(Date date_utilisation) {
        this.date_utilisation = date_utilisation;
    }

    public double getValeur() {
        return valeur;
    }

    public void setValeur(double valeur) {
        this.valeur = valeur;
    }
    public double getAmm_cumule_debut_periode() {
        return amm_cumule_debut_periode;
    }
    public void setAmm_cumule_debut_periode(double amm_cumule_debut_periode) {
        this.amm_cumule_debut_periode = amm_cumule_debut_periode;
    }
    public double getDotation() {
        return dotation;
    }
    public void setDotation(double dotation) {
        this.dotation = dotation;
    }
    public int getTaux() {
        return taux;
    }
    public void setTaux(int taux) {
        this.taux = taux;
    }
    public double getAmm_cumule_fin_periode() {
        return amm_cumule_fin_periode;
    }
    public void setAmm_cumule_fin_periode(double amm_cumule_fin_periode) {
        this.amm_cumule_fin_periode = amm_cumule_fin_periode;
    }
    public double getVNC() {
        return VNC;
    }
    public void setVNC(double vNC) {
        VNC = vNC;
    }
}
