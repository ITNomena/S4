/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ammortissement;

import java.util.ArrayList;

/**
 *
 * @author 1
 */
public class Degressif {
    public double valeur;
    public int TAD;
    public int TAL;
    public double annuite;
    public double VNC;

    public Degressif() {

    }

    public Degressif(double valeur,int tad,int tal,double annuite,double vnc) {
        this.setValeur(valeur);
        this.setTAD(tad);
        this.setTAL(tal);
        this.setAnnuite(annuite);
        this.setVNC(vnc);
    }

    //TAUX AMORTISSEMENT LINEAIRE
    public int getTAL(int nb_annee) {
        double calcul = 100/(double)nb_annee;
        int TAL = (int) Math.floor(calcul);

        return TAL;
    }

    //TAUX AMORTISSEMENT DEGRESSIF
    public int getTAD(double TAL,double coefficient_degressif) {
        double calcul = TAL*coefficient_degressif;
        int TAD = (int) Math.floor(calcul);

        return TAD;
    }

    public double getAnnuiteDegressivePremiereAnnee(double valeur,double TAD, int temps) {
        double annuite = (valeur*TAD*((double) temps/12))/100;
        annuite = Math.round(annuite * 100.0) / 100.0;

        return annuite;
    }

    public double getAnnuiteDegressiveRestante(double valeur,double TAD) {
        double annuite = (valeur*TAD)/100;
        annuite = Math.round(annuite * 100.0) / 100.0;

        return annuite;
    }

    public double getAnnuiteDegressiveRestanteLineaire(double valeur,double TAL) {
        double annuite = (valeur*TAL)/100;
        annuite = Math.round(annuite * 100.0) / 100.0;

        return annuite;
    }

    public ArrayList<Degressif> Amortissement(double base, int nb_annee,int temps) throws Exception {
        ArrayList<Degressif> amortissement = new ArrayList<Degressif>();

        double valeur = base;
        int TAL = this.getTAL(nb_annee);

        CoeffDegressif coeffDegressif = new CoeffDegressif().getCoeffDegressifByYear(null, nb_annee);
        int TAD = this.getTAD(TAL, coeffDegressif.getCoefficient());
        
        double annuite = this.getAnnuiteDegressivePremiereAnnee(valeur, TAD, temps);
        double VNC = valeur - annuite;

        Degressif deg = new Degressif(valeur, TAD, TAL, annuite, VNC);

        amortissement.add(deg);

        // System.out.println(valeur+"      "+TAD+"%     "+TAL+"%     "+annuite+"     "+VNC);

        for (int i = nb_annee-1; i > 0; i--) {
            valeur = VNC;
            TAL = this.getTAL(i);

            annuite = this.getAnnuiteDegressiveRestante(valeur, TAD);
            VNC = valeur - annuite;
            VNC = Math.round(VNC*100.0)/100.0;

            if (i<3) {
                annuite = this.getAnnuiteDegressiveRestanteLineaire(valeur, TAL);
                VNC = valeur - annuite;
                VNC = Math.round(VNC*100.0)/100.0;
            }

            Degressif degressif = new Degressif(valeur, TAD, TAL, annuite, VNC);

            amortissement.add(degressif);

            // System.out.println(valeur+"      "+TAD+"%     "+TAL+"%     "+annuite+"     "+VNC);
        }

        return amortissement;
    }



    public double getValeur() {
        return valeur;
    }

    public void setValeur(double valeur) {
        this.valeur = valeur;
    }

    public int getTAD() {
        return TAD;
    }

    public void setTAD(int tAD) {
        TAD = tAD;
    }

    public int getTAL() {
        return TAL;
    }

    public void setTAL(int tAL) {
        TAL = tAL;
    }

    public double getAnnuite() {
        return annuite;
    }

    public void setAnnuite(double annuite) {
        this.annuite = annuite;
    }

    public double getVNC() {
        return VNC;
    }

    public void setVNC(double vNC) {
        VNC = vNC;
    }

}
