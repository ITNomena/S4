/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ammortissement;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import connection.MyConnection;

/**
 *
 * @author 1
 */
public class CoeffDegressif {
    public int idCoeffDegressif;
    public int annee_min;
    public int annee_max;
    public double coefficient;

    public CoeffDegressif() {
        
    }

    public CoeffDegressif(int idCoeffDegressif, int annee_min, int annee_max, double coefficient) {
        this.setIdCoeffDegressif(idCoeffDegressif);
        this.setAnnee_min(annee_min);
        this.setAnnee_max(annee_max);
        this.setCoefficient(coefficient);
    }

    public CoeffDegressif getCoeffDegressifByYear(Connection connect,int nb_annee)throws Exception {
        CoeffDegressif coeffDegressif = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query = "select * from coeff_degressif where "+nb_annee+" between annee_min and annee_max";

        // System.out.println(query);

        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            coeffDegressif = new CoeffDegressif(rs.getInt("idcoeffdegressif"), rs.getInt("annee_min"), rs.getInt("annee_max"), rs.getDouble("coefficient"));
        }
        rs.close();
        st.close();
        connect.close();

        return coeffDegressif;
    }

    public int getIdCoeffDegressif() {
        return idCoeffDegressif;
    }
    public void setIdCoeffDegressif(int idCoeffDegressif) {
        this.idCoeffDegressif = idCoeffDegressif;
    }
    public int getAnnee_min() {
        return annee_min;
    }
    public void setAnnee_min(int annee_min) {
        this.annee_min = annee_min;
    }
    public int getAnnee_max() {
        return annee_max;
    }
    public void setAnnee_max(int annee_max) {
        this.annee_max = annee_max;
    }
    public double getCoefficient() {
        return coefficient;
    }
    public void setCoefficient(double coefficient) {
        this.coefficient = coefficient;
    }
}
