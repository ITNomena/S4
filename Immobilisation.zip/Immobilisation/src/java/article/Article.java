/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package article;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import categorie.Categorie;
import connection.MyConnection;

/**
 *
 * @author 1
 */
public class Article {
    public int idArticle;
    public String nom;
    public Categorie categorie;

    public Article() {

    }

    public Article(int idArticle,String nom, Categorie categorie) {
        this.setIdArticle(idArticle);
        this.setNom(nom);
        this.setCategorie(categorie);
    }

    public ArrayList<Article> getAllArtice(Connection connect) throws Exception {
        ArrayList<Article> list_article = new ArrayList<Article>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from article";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Categorie cat = new Categorie();
            cat.setIdCategorie(rs.getInt("idcategorie"));

            Article categorie = new Article(rs.getInt("idarticle"),rs.getString("nom"),cat);

            list_article.add(categorie);
        }
        rs.close();
        st.close();
        connect.close();

        return list_article;
    }

    public void insertArticle(Connection connect)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into article (nom,idcategorie) values ('"+this.getNom()+"',"+this.getCategorie().getIdCategorie()+")";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdArticle() {
        return idArticle;
    }
    public void setIdArticle(int idArticle) {
        this.idArticle = idArticle;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public Categorie getCategorie() {
        return categorie;
    }
    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }
}
