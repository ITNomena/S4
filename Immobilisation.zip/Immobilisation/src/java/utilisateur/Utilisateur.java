/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utilisateur;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;
import service.Service;

/**
 *
 * @author 1
 */
public class Utilisateur {
    public int idutilisateur;
    public String nom;
    public Service service;
    public String email;
    public String motdepasse;

    public Utilisateur() {

    }

    public Utilisateur(String nom,Service service,String email,String motdepasse) {
        this.setNom(nom);
        this.setService(service);
        this.setEmail(email);
        this.setMotdepasse(motdepasse);
    }

    public Utilisateur(int idutilisateur,String nom,Service service,String email,String motdepasse) {
        this.setIdutilisateur(idutilisateur);
        this.setNom(nom);
        this.setService(service);
        this.setEmail(email);
        this.setMotdepasse(motdepasse);
    }

    public ArrayList<Utilisateur> getAllUtilisateur(Connection connect) throws Exception {
        ArrayList<Utilisateur> list_utilisateur = new ArrayList<Utilisateur>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from utilisateur";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Service srv = new Service();
            srv.setIdService(rs.getInt("idservice"));

            Utilisateur utl = new Utilisateur(rs.getInt("idutilisateur"), rs.getString("nom"), srv, rs.getString("email"), rs.getString("motdepasse"));

            list_utilisateur.add(utl);
        }

        rs.close();
        st.close();
        connect.close();

        return list_utilisateur;
    }

    public int getIdutilisateur() {
        return idutilisateur;
    }
    public void setIdutilisateur(int idutilisateur) {
        this.idutilisateur = idutilisateur;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public Service getService() {
        return service;
    }
    public void setService(Service service) {
        this.service = service;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getMotdepasse() {
        return motdepasse;
    }
    public void setMotdepasse(String motdepasse) {
        this.motdepasse = motdepasse;
    }
}
