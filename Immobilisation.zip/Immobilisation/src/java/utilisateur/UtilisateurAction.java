/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utilisateur;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;

import action.Action;
import action.ActionDetail;
import connection.MyConnection;
import etat.Etat;
import immobilisation.Immobilisation;

/**
 *
 * @author 1
 */
public class UtilisateurAction {
    public int idutilisateuraction;
    public Utilisateur utilisateur;
    public Immobilisation immobilisation;
    public ActionDetail actionDetail;
    public Date dateaction;
    public Time heureaction;

    public String dateaction_string;
    public String heureaction_string;

    public UtilisateurAction() {

    }

    public UtilisateurAction(Utilisateur utilisateur,Immobilisation immobilisation,ActionDetail actiondetail,Date dateaction,Time heureaction) {
        this.setUtilisateur(utilisateur);
        this.setImmobilisation(immobilisation);
        this.setActionDetail(actiondetail);
        this.setDateaction(dateaction);
        this.setHeureaction(heureaction);
    }

    public UtilisateurAction(Utilisateur utilisateur,Immobilisation immobilisation,ActionDetail actiondetail,String dateaction_string,String heureaction_string) {
        this.setUtilisateur(utilisateur);
        this.setImmobilisation(immobilisation);
        this.setActionDetail(actiondetail);
        this.setDateaction_string(dateaction_string);
        this.setHeureaction_string(heureaction_string);
    }

    public UtilisateurAction(int idutilisateuraction,Utilisateur utilisateur,Immobilisation immobilisation,ActionDetail actiondetail,Date dateaction,Time heureaction) {
        this.setIdutilisateuraction(idutilisateuraction);
        this.setUtilisateur(utilisateur);
        this.setImmobilisation(immobilisation);
        this.setActionDetail(actiondetail);
        this.setDateaction(dateaction);
        this.setHeureaction(heureaction);
    }

    public UtilisateurAction(int idutilisateuraction,Utilisateur utilisateur,Immobilisation immobilisation,ActionDetail actiondetail,String dateaction_string,String heureaction_string) {
        this.setIdutilisateuraction(idutilisateuraction);
        this.setUtilisateur(utilisateur);
        this.setImmobilisation(immobilisation);
        this.setActionDetail(actiondetail);
        this.setDateaction_string(dateaction_string);
        this.setHeureaction_string(heureaction_string);
    }

    public ArrayList<UtilisateurAction> getAllUtilisateurAction(Connection connect) throws Exception {
        ArrayList<UtilisateurAction> list_utilisateuraction = new ArrayList<UtilisateurAction>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from v_plusdetail";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Utilisateur utilisateur = new Utilisateur();
            utilisateur.setNom(rs.getString("nom"));

            Immobilisation immo = new Immobilisation();
            immo.setCode(rs.getString("code"));

            Action action = new Action();
            action.setAction(rs.getString("action"));

            ActionDetail actionDetail = new ActionDetail();
            actionDetail.setAction(action);
            actionDetail.setDetail(rs.getString("detail"));

            UtilisateurAction utilisateurAction = new UtilisateurAction(utilisateur, immo, actionDetail, rs.getDate("dateaction"), rs.getTime("heureaction"));

            list_utilisateuraction.add(utilisateurAction);
        }

        rs.close();
        st.close();
        connect.close();

        return list_utilisateuraction;
    }

    public void insertUtilisateurAction(Connection connect)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into utilisateuraction (idutilisateur,idimmobilisation,idactiondetail,dateaction,heureaction) values ("+this.getUtilisateur().getIdutilisateur()+","+this.getImmobilisation().getIdimmobilisation()+","+this.getActionDetail().getIdactiondetail()+",'"+this.getDateaction_string()+"','"+this.getHeureaction_string()+"')";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdutilisateuraction() {
        return idutilisateuraction;
    }
    public void setIdutilisateuraction(int idutilisateuraction) {
        this.idutilisateuraction = idutilisateuraction;
    }
    public Utilisateur getUtilisateur() {
        return utilisateur;
    }
    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }
    public Immobilisation getImmobilisation() {
        return immobilisation;
    }
    public void setImmobilisation(Immobilisation immobilisation) {
        this.immobilisation = immobilisation;
    }
    public ActionDetail getActionDetail() {
        return actionDetail;
    }
    public void setActionDetail(ActionDetail actionDetail) {
        this.actionDetail = actionDetail;
    }
    public Date getDateaction() {
        return dateaction;
    }
    public void setDateaction(Date dateaction) {
        this.dateaction = dateaction;
    }
    public Time getHeureaction() {
        return heureaction;
    }
    public void setHeureaction(Time heureaction) {
        this.heureaction = heureaction;
    }
    public String getDateaction_string() {
        return dateaction_string;
    }

    public void setDateaction_string(String dateaction_string) {
        this.dateaction_string = dateaction_string;
    }

    public String getHeureaction_string() {
        return heureaction_string;
    }

    public void setHeureaction_string(String heureaction_string) {
        this.heureaction_string = heureaction_string;
    }
}
