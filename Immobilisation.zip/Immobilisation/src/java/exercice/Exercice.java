/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercice;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import connection.MyConnection;

/**
 *
 * @author 1
 */
public class Exercice {
    public int idexercice;
    public String nomexercice;
    public Date datedebut;
    public Date datedefin;

    public Exercice() {

    }

    public Exercice(int idexercice,String nomexercie,Date datedebut,Date datefin) {
        this.setIdexercice(idexercice);
        this.setNomexercice(nomexercie);
        this.setDatedebut(datedebut);
        this.setDatedefin(datefin);
    }

    public Exercice getExercice(Connection connect) throws Exception {
        Exercice exercice = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from exercice";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            exercice = new Exercice(rs.getInt("idexercice"),rs.getString("nomexercice"),rs.getDate("datedebut"),rs.getDate("datefin"));
        }

        rs.close();
        st.close();
        connect.close();

        return exercice;
    }


    public int getIdexercice() {
        return idexercice;
    }
    public void setIdexercice(int idexercice) {
        this.idexercice = idexercice;
    }
    public String getNomexercice() {
        return nomexercice;
    }
    public void setNomexercice(String nomexercice) {
        this.nomexercice = nomexercice;
    }
    public Date getDatedebut() {
        return datedebut;
    }
    public void setDatedebut(Date datedebut) {
        this.datedebut = datedebut;
    }
    public Date getDatedefin() {
        return datedefin;
    }
    public void setDatedefin(Date datedefin) {
        this.datedefin = datedefin;
    }
}
