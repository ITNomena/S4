/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pv;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import article.Article;
import connection.MyConnection;
import etat.Etat;
import immobilisation.Immobilisation;

/**
 *
 * @author 1
 */
public class Reception {
    public int idpvreception;
    public Immobilisation immobilisation;
    public Etat etat;
    public Date datepv_reception;
    public int annee_amortissemnt;

    public String datepv_reception_string;

    public Reception() {

    }

    public Reception(Immobilisation immobilisation,Etat etat, String datepv_reception_string,int annee_amortissemnt) {
        this.setImmobilisation(immobilisation);
        this.setEtat(etat);
        this.setDatepv_reception_string(datepv_reception_string);
        this.setAnnee_amortissemnt(annee_amortissemnt);
    }

    public Reception(Immobilisation immobilisation,Etat etat, Date datepv_reception,int annee_amortissemnt) {
        this.setImmobilisation(immobilisation);
        this.setEtat(etat);
        this.setDatepv_reception(datepv_reception);
        this.setAnnee_amortissemnt(annee_amortissemnt);
    }

    public Reception(int idpvreception,Immobilisation immobilisation,Etat etat, Date datepv_reception,int annee_amortissemnt) {
        this.setIdpvreception(idpvreception);
        this.setImmobilisation(immobilisation);
        this.setEtat(etat);
        this.setDatepv_reception(datepv_reception);
        this.setAnnee_amortissemnt(annee_amortissemnt);
    }

    public Reception getReceptionByIdImmobilisation(Connection connect,int id_immobilisation) throws Exception {
        Reception reception = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from pv_reception where idimmobilisation="+id_immobilisation;
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Immobilisation immo = new Immobilisation();
            immo.setIdimmobilisation(rs.getInt("idimmobilisation"));

            Etat et = new Etat();
            et.setIdEtat(rs.getInt("idetat"));

            reception = new Reception(rs.getInt("idpvreception"),immo,et,rs.getDate("datepv_reception"),rs.getInt("annee_amortissement"));

        }
        
        rs.close();
        st.close();
        connect.close();

        return reception;
    }

    public ArrayList<Reception> getAllReception(Connection connect) throws Exception {
        ArrayList<Reception> list_reception = new ArrayList<Reception>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select pv_reception.idpvreception,immobilisation.code,etat.etat,pv_reception.datepv_reception,pv_reception.annee_amortissement from pv_reception join immobilisation on immobilisation.idimmobilisation=pv_reception.idimmobilisation join etat on etat.idetat=pv_reception.idetat";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Immobilisation immo = new Immobilisation();
            immo.setCode(rs.getString("code"));

            Etat et = new Etat();
            et.setEtat(rs.getString("etat"));

            Reception recep = new Reception(rs.getInt("idpvreception"),immo,et,rs.getDate("datepv_reception"),rs.getInt("annee_amortissement"));

            list_reception.add(recep);
        }
        rs.close();
        st.close();
        connect.close();

        return list_reception;
    }

    public void insertReception(Connection connect)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into pv_reception (idimmobilisation,idetat,datepv_reception,annee_amortissement) values ("+this.getImmobilisation().getIdimmobilisation()+","+this.getEtat().getIdEtat()+",'"+this.getDatepv_reception_string()+"',"+this.getAnnee_amortissemnt()+")";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdpvreception() {
        return idpvreception;
    }
    public void setIdpvreception(int idpvreception) {
        this.idpvreception = idpvreception;
    }
    public Immobilisation getImmobilisation() {
        return immobilisation;
    }
    public void setImmobilisation(Immobilisation immobilisation) {
        this.immobilisation = immobilisation;
    }
    public Etat getEtat() {
        return etat;
    }
    public void setEtat(Etat etat) {
        this.etat = etat;
    }
    public Date getDatepv_reception() {
        return datepv_reception;
    }
    public void setDatepv_reception(Date datepv_reception) {
        this.datepv_reception = datepv_reception;
    }
    public int getAnnee_amortissemnt() {
        return annee_amortissemnt;
    }

    public void setAnnee_amortissemnt(int annee_amortissemnt) {
        this.annee_amortissemnt = annee_amortissemnt;
    }
    public String getDatepv_reception_string() {
        return datepv_reception_string;
    }

    public void setDatepv_reception_string(String datepv_reception_string) {
        this.datepv_reception_string = datepv_reception_string;
    }
}
