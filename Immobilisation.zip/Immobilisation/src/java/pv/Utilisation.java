/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pv;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import article.Article;
import connection.MyConnection;
import etat.Etat;
import immobilisation.Immobilisation;

/**
 *
 * @author 1
 */
public class Utilisation {
    public int idpvutilisation;
    public Immobilisation immobilisation;
    public Etat etat;
    public Date datepv_utilisation;

    public String datepv_utilisation_string;
    public int mois_restant;

    public Utilisation() {

    }

    public Utilisation(Immobilisation immobilisation,Etat etat, String datepv_utilisation_string) {
        this.setImmobilisation(immobilisation);
        this.setEtat(etat);
        this.setDatepv_utilisation_string(datepv_utilisation_string);
    }

    public Utilisation(Immobilisation immobilisation,Etat etat, Date datepv_utilisation) {
        this.setImmobilisation(immobilisation);
        this.setEtat(etat);
        this.setDatepv_utilisation(datepv_utilisation);
    }

    public Utilisation(int idpvutilisation,Immobilisation immobilisation) {
        this.setIdpvutilisation(idpvutilisation);
        this.setImmobilisation(immobilisation);
    }

    public Utilisation(int idpvutilisation,Immobilisation immobilisation,Etat etat, Date datepv_utilisation) {
        this.setIdpvutilisation(idpvutilisation);
        this.setImmobilisation(immobilisation);
        this.setEtat(etat);
        this.setDatepv_utilisation(datepv_utilisation);
    }

    public Utilisation(int idpvutilisation,Immobilisation immobilisation,Etat etat, Date datepv_utilisation,int mois_restant) {
        this.setIdpvutilisation(idpvutilisation);
        this.setImmobilisation(immobilisation);
        this.setEtat(etat);
        this.setDatepv_utilisation(datepv_utilisation);
        this.setMois_restant(mois_restant);
    }

    public Utilisation(Immobilisation immobilisation, Date datepv_utilisation) {
        this.setImmobilisation(immobilisation);
        this.setDatepv_utilisation(datepv_utilisation);
    }

    public Utilisation getUtilisationByIdImmobilisation(Connection connect,int id_immobilisation) throws Exception {
        Utilisation utilisation = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select pv_util.datepv_utilisation,immo.idimmobilisation,immo.code,immo.prix from pv_utilisation pv_util join immobilisation immo on immo.idimmobilisation=pv_util.idimmobilisation where pv_util.idimmobilisation="+id_immobilisation;
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Immobilisation immo = new Immobilisation();
            immo.setIdimmobilisation(rs.getInt("idimmobilisation"));
            immo.setCode(rs.getString("code"));
            immo.setPrix(rs.getDouble("prix"));

            utilisation = new Utilisation(immo,rs.getDate("datepv_utilisation"));

        }

        rs.close();
        st.close();
        connect.close();

        return utilisation;
    }

    public Utilisation getUtilisation(Connection connect,int id_immobilisation) throws Exception {
        Utilisation utilisation = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select idpvutilisation,idimmobilisation,idetat,datepv_utilisation,12 - EXTRACT(MONTH FROM datepv_utilisation) + 1 AS mois_restants from pv_utilisation where idimmobilisation="+id_immobilisation;
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Immobilisation immo = new Immobilisation();
            immo.setIdimmobilisation(rs.getInt("idimmobilisation"));

            Etat et = new Etat();
            et.setIdEtat(rs.getInt("idetat"));;

            utilisation = new Utilisation(rs.getInt("idpvutilisation"),immo,et,rs.getDate("datepv_utilisation"),rs.getInt("mois_restants"));

        }

        rs.close();
        st.close();
        connect.close();

        return utilisation;
    }

    public ArrayList<Utilisation> getAllUtilisation(Connection connect) throws Exception {
        ArrayList<Utilisation> list_utilisation = new ArrayList<Utilisation>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select pv_utilisation.idpvutilisation,immobilisation.idimmobilisation,immobilisation.code,etat.etat,pv_utilisation.datepv_utilisation from pv_utilisation join immobilisation on immobilisation.idimmobilisation=pv_utilisation.idimmobilisation join etat on etat.idetat=pv_utilisation.idetat";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Immobilisation immo = new Immobilisation();
            immo.setIdimmobilisation(rs.getInt("idimmobilisation"));
            immo.setCode(rs.getString("code"));

            Etat et = new Etat();
            et.setEtat(rs.getString("etat"));

            Utilisation util = new Utilisation(immo,et,rs.getDate("datepv_utilisation"));

            list_utilisation.add(util);
        }

        rs.close();
        st.close();
        connect.close();

        return list_utilisation;
    }

    public void insertUtilisation(Connection connect)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into pv_utilisation (idimmobilisation,idetat,datepv_utilisation) values ("+this.getImmobilisation().getIdimmobilisation()+","+this.getEtat().getIdEtat()+",'"+this.getDatepv_utilisation_string()+"')";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdpvutilisation() {
        return idpvutilisation;
    }
    public void setIdpvutilisation(int idpvutilisation) {
        this.idpvutilisation = idpvutilisation;
    }
    public Immobilisation getImmobilisation() {
        return immobilisation;
    }
    public void setImmobilisation(Immobilisation immobilisation) {
        this.immobilisation = immobilisation;
    }
    public Etat getEtat() {
        return etat;
    }
    public void setEtat(Etat etat) {
        this.etat = etat;
    }
    public Date getDatepv_utilisation() {
        return datepv_utilisation;
    }
    public void setDatepv_utilisation(Date datepv_utilisation) {
        this.datepv_utilisation = datepv_utilisation;
    }
    public String getDatepv_utilisation_string() {
        return datepv_utilisation_string;
    }

    public void setDatepv_utilisation_string(String datepv_utilisation_string) {
        this.datepv_utilisation_string = datepv_utilisation_string;
    }
    public int getMois_restant() {
        return mois_restant;
    }

    public void setMois_restant(int mois_restant) {
        this.mois_restant = mois_restant;
    }

}
