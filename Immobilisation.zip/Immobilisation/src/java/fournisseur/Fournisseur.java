/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fournisseur;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;

/**
 *
 * @author 1
 */
public class Fournisseur {
    public int idFournisseur;
    public String nom;
    public String localisation;
    public String email;
    public String contact;

    public Fournisseur() {

    }

    public Fournisseur(String nom,String localisation,String email,String contact) {
        this.setNom(nom);
        this.setLocalisation(localisation);
        this.setEmail(email);
        this.setContact(contact);
    }

    public Fournisseur(int idFournisseur,String nom,String localisation,String email,String contact) {
        this.setIdFournisseur(idFournisseur);
        this.setNom(nom);
        this.setLocalisation(localisation);
        this.setEmail(email);
        this.setContact(contact);
    }

    public ArrayList<Fournisseur> getAllFournisseur(Connection connect) throws Exception {
        ArrayList<Fournisseur> list_fournisseur = new ArrayList<Fournisseur>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from fournisseur";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Fournisseur fournisseur = new Fournisseur(rs.getInt("idfournisseur"),rs.getString("nom"),rs.getString("localisation"),rs.getString("email"),rs.getString("contact"));            

            list_fournisseur.add(fournisseur);
        }
        rs.close();
        st.close();
        connect.close();

        return list_fournisseur;
    }

    public void insertFournisseur(Connection connect)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into fournisseur (nom,localisation,email,contact) values ('"+this.getNom()+"','"+this.getLocalisation()+"','"+this.getEmail()+"','"+this.getContact()+"')";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdFournisseur() {
        return idFournisseur;
    }
    public void setIdFournisseur(int idFournisseur) {
        this.idFournisseur = idFournisseur;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public String getLocalisation() {
        return localisation;
    }
    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getContact() {
        return contact;
    }
    public void setContact(String contact) {
        this.contact = contact;
    }
}
