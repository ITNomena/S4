/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;

/**
 *
 * @author 1
 */
public class Service {
    public int idService;
    public String nom;

    public Service() {

    }

    public Service(String nom) {
        this.setNom(nom);
    }

    public Service(int idService,String nom) {
        this.setIdService(idService);
        this.setNom(nom);
    }

    public ArrayList<Service> getAllService(Connection connect) throws Exception {
        ArrayList<Service> list_Service = new ArrayList<Service>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from Service";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Service service = new Service(rs.getInt("idservice"),rs.getString("nom"));

            list_Service.add(service);
        }
        rs.close();
        st.close();
        connect.close();

        return list_Service;
    }

    public void insertService(Connection connect)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into service (nom) values ('"+this.getNom()+"')";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public int getIdService() {
        return idService;
    }
    public void setIdService(int idService) {
        this.idService = idService;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
}
