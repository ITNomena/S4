/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.ArrayList;

import achat.Demande;
import ammortissement.Degressif;
import ammortissement.Lineaire;
import article.Article;
import fournisseur.Fournisseur;
import immobilisation.Immobilisation;
import proforma.DetailProforma;
import proforma.Proforma;
import pv.Reception;
import pv.Utilisation;
import service.Service;

/**
 *
 * @author 1
 */
public class Main {
    public static void main(String[] args) {
        try {
            // Immobilisation immo = new Immobilisation().getImmobilisationById(null, 1);
            // Reception reception = new Reception().getReceptionByIdImmobilisation(null, 1);
            // Utilisation util = new Utilisation().getUtilisation(null, 1);

            // Degressif degressif = new Degressif();
            // ArrayList<Degressif> amortissement = degressif.Amortissement(immo.getPrix(), reception.getAnnee_amortissemnt(), util.getMois_restant());

            // for (int i = 0; i < amortissement.size(); i++) {
            //     System.out.println(amortissement.get(i).getValeur()+"      "+amortissement.get(i).getTAD()+"%     "+amortissement.get(i).getTAL()+"%     "+amortissement.get(i).getAnnuite()+"     "+amortissement.get(i).getVNC());
            // }

            // Service service = new Service();
            // service.setIdService(1);

            // Article article = new Article();
            // article.setIdArticle(1);

            // Demande demande = new Demande(service,article,3);
            // demande.insertDemande(null);

            // Fournisseur fournisseur = new Fournisseur();
            // fournisseur.setIdFournisseur(1);

            // Proforma proforma = new Proforma(fournisseur,"PRO0001");
            // proforma.insertProforma(null);

            // Proforma proforma = new Proforma();
            // proforma.setIdProforma(1);

            // DetailProforma detailProforma = new DetailProforma(proforma,article,3,2000,"2024-01-26");
            // detailProforma.insertDetailProforma(null);

            Lineaire lineaire = new Lineaire();
            ArrayList<Lineaire> amortissement = lineaire.Amortissement(1, 20);

            for (int i = 0; i < amortissement.size(); i++) {
                System.out.println(amortissement.get(i).getCode()+"      "+amortissement.get(i).getDate_utilisation()+"     "+amortissement.get(i).getValeur()+"     "+amortissement.get(i).getAmm_cumule_debut_periode()+"     "+amortissement.get(i).getDotation()+ "    " +amortissement.get(i).getTaux()+"      "+amortissement.get(i).getAmm_cumule_fin_periode()+"    "+amortissement.get(i).getVNC());
            }

        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        
    }
}
