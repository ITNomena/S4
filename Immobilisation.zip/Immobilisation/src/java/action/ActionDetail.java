/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package action;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;

/**
 *
 * @author 1
 */
public class ActionDetail {
    public int idactiondetail;
    public Action action;
    public String detail;

    public ActionDetail() {

    }

    public ActionDetail(Action action,String detail) {
        this.setAction(action);
        this.setDetail(detail);
    }

    public ActionDetail(int idactiondetail,Action action,String detail) {
        this.setIdactiondetail(idactiondetail);
        this.setAction(action);
        this.setDetail(detail);
    }

    public ArrayList<ActionDetail> getAllActionDetail(Connection connect) throws Exception {
        ArrayList<ActionDetail> list_actiondetail = new ArrayList<ActionDetail>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select actiondetail.idactiondetail,action.action,actiondetail.detail from actiondetail join action on action.idaction=actiondetail.idaction";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Action act = new Action();
            act.setAction(rs.getString("action"));

            ActionDetail actdetail = new ActionDetail(rs.getInt("idactiondetail"), act, rs.getString("detail"));

            list_actiondetail.add(actdetail);
        }

        rs.close();
        st.close();
        connect.close();

        return list_actiondetail;
    }

    public int getIdactiondetail() {
        return idactiondetail;
    }
    public void setIdactiondetail(int idactiondetail) {
        this.idactiondetail = idactiondetail;
    }
    public Action getAction() {
        return action;
    }
    public void setAction(Action action) {
        this.action = action;
    }
    public String getDetail() {
        return detail;
    }
    public void setDetail(String detail) {
        this.detail = detail;
    }
}
