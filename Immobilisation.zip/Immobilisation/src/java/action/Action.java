/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package action;

/**
 *
 * @author 1
 */
public class Action {
    public int idaction;
    public String action;

    public Action() {

    }

    public Action(String action) {
        this.setAction(action);
    }

    public Action(int idaction, String action) {
        this.setIdaction(idaction);
        this.setAction(action);
    }

    public int getIdaction() {
        return idaction;
    }
    public void setIdaction(int idaction) {
        this.idaction = idaction;
    }
    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
}
