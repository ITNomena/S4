/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package achat;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import article.Article;
import connection.MyConnection;
import service.Service;

/**
 *
 * @author 1
 */
public class Demande {
    public int idDemandeAchat;
    public Date date;
    public Service service;
    public Article article;
    public int quantite;
    public int confirm;
    public int receive;

    public String date_demande;

    public Demande() {

    }

    public Demande(Date date,Service service,Article article,int quantite,int confirm,int receive) {
        this.setDate(date);
        this.setService(service);
        this.setArticle(article);
        this.setQuantite(quantite);
        this.setConfirm(confirm);
        this.setReceive(receive);
    }

    public Demande(Service service,Article article,int quantite) {
        this.setService(service);
        this.setArticle(article);
        this.setQuantite(quantite);
    }

    public Demande(int idDemandeAchat,Date date,Service service,Article article,int quantite,int confirm,int receive) {
        this.setIdDemandeAchat(idDemandeAchat);
        this.setDate(date);
        this.setService(service);
        this.setArticle(article);
        this.setQuantite(quantite);
        this.setConfirm(confirm);
        this.setReceive(receive);
    }

    public void updateDemandeConfirm(Connection connect,int iddemandeachat)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="update demande_achat set confirm=1 where iddemandeachat="+iddemandeachat;
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public ArrayList<Demande> getDemandeConfirmNotReceive(Connection connect) throws Exception {
        ArrayList<Demande> list_demande = new ArrayList<Demande>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select demande_achat.iddemandeachat,article.name as article,sum(demande_achat.quantite) as quantite, demande_achat.confirm as confirm from demande_achat join article on article.idarticle=demande_achat.idarticle "+
                    "where demande_achat.confirm=1 and demande_achat.receive=0 group by article.name,demande_achat.confirm order by quantite desc";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Article art = new Article();
            art.setNom(rs.getString("article"));

            Demande demande = new Demande();
            demande.setArticle(art);
            demande.setIdDemandeAchat(rs.getInt("iddemandeachat"));
            demande.setQuantite(rs.getInt("quantite"));
            demande.setConfirm(rs.getInt("confirm"));

            list_demande.add(demande);
        }
        rs.close();
        st.close();
        connect.close();

        return list_demande;
    }

    public ArrayList<Demande> getDemandeNotConfirm(Connection connect) throws Exception {
        ArrayList<Demande> list_demande = new ArrayList<Demande>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select demandea_chat.iddemandeachat,article.name as article,sum(demande_achat.quantite) as quantite, demande_achat.confirm as confirm from demande_achat join article on article.idarticle=demande_achat.idarticle "+
                    "where demande_achat.confirm=0 group by article.name,demande_achat.confirm order by quantite desc";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Article art = new Article();
            art.setNom(rs.getString("article"));

            Demande demande = new Demande();
            demande.setArticle(art);
            demande.setIdDemandeAchat(rs.getInt("iddemandeachat"));
            demande.setQuantite(rs.getInt("quantite"));
            demande.setConfirm(rs.getInt("confirm"));

            list_demande.add(demande);
        }
        rs.close();
        st.close();
        connect.close();

        return list_demande;
    }

    public void insertDemande(Connection connect)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into demande_achat (date,idservice,idarticle,quantite,confirm,receive) values (CURRENT_DATE,"+this.getService().getIdService()+","+this.getArticle().getIdArticle()+","+this.getQuantite()+",0,0)";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }


    public int getIdDemandeAchat() {
        return idDemandeAchat;
    }
    public void setIdDemandeAchat(int idDemandeAchat) {
        this.idDemandeAchat = idDemandeAchat;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public Service getService() {
        return service;
    }
    public void setService(Service service) {
        this.service = service;
    }
    public Article getArticle() {
        return article;
    }
    public void setArticle(Article article) {
        this.article = article;
    }
    public int getQuantite() {
        return quantite;
    }
    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }
    public int getConfirm() {
        return confirm;
    }
    public void setConfirm(int confirm) {
        this.confirm = confirm;
    }
    public int getReceive() {
        return receive;
    }
    public void setReceive(int receive) {
        this.receive = receive;
    }
    public String getDate_demande() {
        return date_demande;
    }

    public void setDate_demande(String date_demande) {
        this.date_demande = date_demande;
    }
}
