/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package etat;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;

/**
 *
 * @author 1
 */
public class Etat {
    public int idEtat;
    public String etat;

    public Etat() {

    }

    public Etat(String etat) {
        this.setEtat(etat);
    }

    public ArrayList<Etat> getAllEtat(Connection connect) throws Exception {
        ArrayList<Etat> list_etat = new ArrayList<Etat>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from Etat";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Etat etat = new Etat(rs.getInt("idetat"),rs.getString("etat"));

            list_etat.add(etat);
        }
        rs.close();
        st.close();
        connect.close();

        return list_etat;
    }

    public Etat(int idEtat,String etat) {
        this.setIdEtat(idEtat);
        this.setEtat(etat);
    }

    public int getIdEtat() {
        return idEtat;
    }
    public void setIdEtat(int idEtat) {
        this.idEtat = idEtat;
    }
    public String getEtat() {
        return etat;
    }
    public void setEtat(String etat) {
        this.etat = etat;
    }
}
