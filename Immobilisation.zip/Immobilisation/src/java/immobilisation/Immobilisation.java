/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package immobilisation;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import article.Article;
import connection.MyConnection;

/**
 *
 * @author 1
 */
public class Immobilisation {
    public int idimmobilisation;
    public Article article;
    public String code;
    public String immobilisation;
    public double prix;

    public Immobilisation() {

    }

    public Immobilisation(Article article,String code,String immobilisation,double prix) {
        this.setArticle(article);
        this.setCode(code);
        this.setImmobilisation(immobilisation);
        this.setPrix(prix);
    }

    public Immobilisation(int idimmobilisation,Article article,String code,String immobilisation,double prix) {
        this.setIdimmobilisation(idimmobilisation);
        this.setArticle(article);
        this.setCode(code);
        this.setImmobilisation(immobilisation);
        this.setPrix(prix);
    }

    public Immobilisation getImmobilisationById(Connection connect,int id_immobilisation) throws Exception {
        Immobilisation immobilisation = null;

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from immobilisation where idimmobilisation="+id_immobilisation;
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Article art = new Article();
            art.setIdArticle(rs.getInt("idarticle"));

            immobilisation = new Immobilisation(rs.getInt("idimmobilisation"),art,rs.getString("code"),rs.getString("immobilisation"),rs.getDouble("prix"));

        }

        return immobilisation;
    }

    public ArrayList<Immobilisation> getAllImmobilisation(Connection connect) throws Exception {
        ArrayList<Immobilisation> list_immobilisation = new ArrayList<Immobilisation>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select immobilisation.idimmobilisation,article.nom as article,immobilisation.code,immobilisation.immobilisation,immobilisation.prix from immobilisation join article on article.idarticle=immobilisation.idarticle";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Article art = new Article();
            art.setNom(rs.getString("article"));

            Immobilisation immobilisation = new Immobilisation(rs.getInt("idimmobilisation"),art,rs.getString("code"),rs.getString("immobilisation"),rs.getDouble("prix"));

            list_immobilisation.add(immobilisation);
        }

        rs.close();
        st.close();
        connect.close();

        return list_immobilisation;
    }

    public int getIdimmobilisation() {
        return idimmobilisation;
    }
    public void setIdimmobilisation(int idimmobilisation) {
        this.idimmobilisation = idimmobilisation;
    }
    public Article getArticle() {
        return article;
    }
    public void setArticle(Article article) {
        this.article = article;
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getImmobilisation() {
        return immobilisation;
    }
    public void setImmobilisation(String immobilisation) {
        this.immobilisation = immobilisation;
    }
    public double getPrix() {
        return prix;
    }
    public void setPrix(double prix) {
        this.prix = prix;
    }
}
