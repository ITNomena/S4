/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import action.ActionDetail;
import immobilisation.Immobilisation;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import utilisateur.Utilisateur;
import utilisateur.UtilisateurAction;
import jakarta.servlet.RequestDispatcher;

/**
 *
 * @author 1
 */
@WebServlet(name = "PlusDetailServlet", urlPatterns = {"/PlusDetailServlet"})
public class PlusDetailServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet PlusDetailServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet PlusDetailServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // processRequest(request, response);
        try {
            Utilisateur utilisateur = new Utilisateur();
            ArrayList<Utilisateur> list_utilisateur = utilisateur.getAllUtilisateur(null);

            Immobilisation immobilisation = new Immobilisation();
            ArrayList<Immobilisation> list_immobilisation = immobilisation.getAllImmobilisation(null);

            ActionDetail actionDetail = new ActionDetail();
            ArrayList<ActionDetail> list_actiondetail = actionDetail.getAllActionDetail(null);

            UtilisateurAction utilisateurAction = new UtilisateurAction();
            ArrayList<UtilisateurAction> list_plusdetail = utilisateurAction.getAllUtilisateurAction(null);

            request.setAttribute("listUtilisateur",list_utilisateur);
            request.setAttribute("listImmobilisation",list_immobilisation);
            request.setAttribute("listActionDetail",list_actiondetail);
            request.setAttribute("plusDetail",list_plusdetail);
        } catch (Exception e) {
            // TODO: handle exception
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/PlusDetail.jsp");
        dispat.forward(request,response); 
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // processRequest(request, response);
        try {
            String utilisateur = request.getParameter("utilisateur");
            String immobilisation = request.getParameter("immobilisation");
            String actiondetail = request.getParameter("actiondetail");
            String dateaction = request.getParameter("date");
            String heureaction = request.getParameter("heure");

            Utilisateur utl = new Utilisateur();
            utl.setIdutilisateur(Integer.parseInt(utilisateur));

            Immobilisation immo = new Immobilisation();
            immo.setIdimmobilisation(Integer.parseInt(immobilisation));

            ActionDetail actdetail = new ActionDetail();
            actdetail.setIdactiondetail(Integer.parseInt(actiondetail));

            UtilisateurAction utilisateurAction = new UtilisateurAction(utl, immo, actdetail, dateaction, heureaction);
            utilisateurAction.insertUtilisateurAction(null);
        } catch (Exception e) {
            // TODO: handle exception
        }
        response.sendRedirect("PlusDetailServlet");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
