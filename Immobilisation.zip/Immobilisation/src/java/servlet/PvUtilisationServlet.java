/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import etat.Etat;
import immobilisation.Immobilisation;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import pv.Utilisation;
import jakarta.servlet.RequestDispatcher;

/**
 *
 * @author 1
 */
@WebServlet(name = "PvUtilisationServlet", urlPatterns = {"/PvUtilisationServlet"})
public class PvUtilisationServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet PvUtilisationServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet PvUtilisationServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // processRequest(request, response);
        try {
            Immobilisation immobilisation = new Immobilisation();
            ArrayList<Immobilisation> list_Immobilisations = immobilisation.getAllImmobilisation(null);

            Etat etat = new Etat();
            ArrayList<Etat> list_etat = etat.getAllEtat(null);

            Utilisation utilisation = new Utilisation();
            ArrayList<Utilisation> list_utilisation = utilisation.getAllUtilisation(null);

            request.setAttribute("listImmobilisation",list_Immobilisations);
            request.setAttribute("listEtat",list_etat);
            request.setAttribute("listUtilisation",list_utilisation);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }

        RequestDispatcher dispat = request.getRequestDispatcher("/PvUtilisation.jsp");
        dispat.forward(request,response); 
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // processRequest(request, response);
        try {
            String immobilisation = request.getParameter("immobilisation");
            String etat = request.getParameter("etat");
            String date = request.getParameter("date");

            Immobilisation immo = new Immobilisation();
            immo.setIdimmobilisation(Integer.parseInt(immobilisation));

            Etat et = new Etat();
            et.setIdEtat(Integer.parseInt(etat));

            Utilisation utilisation = new Utilisation(immo, et, date);
            utilisation.insertUtilisation(null);
        } catch (Exception e) {
            // TODO: handle exception
        }
        response.sendRedirect("PvUtilisationServlet");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
