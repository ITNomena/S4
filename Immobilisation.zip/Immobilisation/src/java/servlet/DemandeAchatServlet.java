/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import achat.Demande;
import article.Article;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import service.Service;
import jakarta.servlet.RequestDispatcher;

/**
 *
 * @author 1
 */
@WebServlet(name = "DemandeAchatServlet", urlPatterns = {"/DemandeAchatServlet"})
public class DemandeAchatServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DemandeAchatServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet DemandeAchatServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // processRequest(request, response);
        try {
            Service service = new Service();
            ArrayList<Service> list_service = service.getAllService(null);

            Article article = new Article();
            ArrayList<Article> list_article = article.getAllArtice(null);

            request.setAttribute("listService",list_service);
            request.setAttribute("listArticle",list_article);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        RequestDispatcher dispat = request.getRequestDispatcher("/DemandeAchat.jsp");
        dispat.forward(request,response); 
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // processRequest(request, response);
        try {
            String service = request.getParameter("service");
            String article = request.getParameter("article");
            String quantite = request.getParameter("quantite");

            Service srv = new Service();
            srv.setIdService(Integer.parseInt(service));

            Article art = new Article();
            art.setIdArticle(Integer.parseInt(article));

            Demande demande = new Demande(srv, art, Integer.parseInt(quantite));
            demande.insertDemande(null);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        response.sendRedirect("DemandeAchatServlet");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
