/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package categorie;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connection.MyConnection;

/**
 *
 * @author 1
 */
public class Categorie {
    public int idCategorie;
    public String nom;

    public Categorie() {
        
    }

    public Categorie(String nom) {
        this.setNom(nom);
    }

    public Categorie(int idCategorie,String nom) {
        this.setIdCategorie(idCategorie);
        this.setNom(nom);
    }

    public ArrayList<Categorie> getAllCategorie(Connection connect) throws Exception {
        ArrayList<Categorie> list_categorie = new ArrayList<Categorie>();

        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        Statement st = connect.createStatement();
        String query ="select * from categorie";
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {
            Categorie categorie = new Categorie(rs.getInt("idcategorie"),rs.getString("nom"));

            list_categorie.add(categorie);
        }
        rs.close();
        st.close();
        connect.close();

        return list_categorie;
    }

    public void insertCategorie(Connection connect)throws Exception {
        
        if(connect==null){
            connect=MyConnection.connexion("postgres");
        }

        String query="insert into categorie (nom) values ('"+this.getNom()+"')";
        System.out.println(query);
        try{
            PreparedStatement ps = connect.prepareStatement(query);
            int nombreLignesAffectees = ps.executeUpdate();
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public int getIdCategorie() {
        return idCategorie;
    }
    public void setIdCategorie(int idCategorie) {
        this.idCategorie = idCategorie;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
}
