create database immobilisation;
\c immobilisation;


create table Categorie(
        idCategorie serial primary key,
        categorie varchar
);

create table SousCategorie(
                          idSousCategorie serial primary key,
                          idCategorie integer references Categorie(idCategorie),
                          sousCategorie varchar
);

-- Ajout de données à la table Categorie
INSERT INTO Categorie (categorie)
VALUES
    ('Informatique'),
    ('Electronique'),
    ('Mobilier de bureau');

-- Ajout de données à la table SousCategorie
INSERT INTO SousCategorie (idCategorie, sousCategorie)
VALUES
    (1, 'Ordinateurs portables'),
    (1, 'Imprimantes'),
    (2, 'Appareils photo'),
    (3, 'Bureaux'),
    (3, 'Chaises');

create table Immobilisation(
        idImmobilisation serial primary key,
        idSousCategorie int references SousCategorie(idSousCategorie),
        code varchar(20),
        immobilisation varchar(20),
        priximmobilisation double precision
);

INSERT INTO Immobilisation (idSousCategorie, code, immobilisation, priximmobilisation)
VALUES
    (1, 'IC001', 'Ordinateur portable', 1200.50);


create table Action(
        idAction serial primary key,
        action varchar(30)
);

create table ActionDetail(
    idActionDetail serial primary key,
    idAction int references Action(idAction),
    detail varchar(20)
);

create table ActionImmobilisation(
    idActionImmobilisation serial primary key,
    idSousCategorie int references SousCategorie(idSousCategorie),
    idActionDetail int references ActionDetail(idActionDetail)

);

create table Utilisateur (
                             idUtilisateur serial primary key,
                             nom varchar,
                             email varchar,
                             motdepasse varchar
);

create table Role (
                      idRole serial primary key,
                      role varchar
);

create table Departement (
                             idDepartement serial primary key,
                             departement varchar
);

create table RoleUtilisateur (
                                 idRoleUtilisateur serial primary key,
                                 idRole int,
                                 idUtilisateur int,
                                 idDepartement int,
                                 foreign key (idRole) references Role(idRole),
                                 foreign key (idUtilisateur) references Utilisateur(idUtilisateur),
                                 foreign key (idDepartement) references Departement(idDepartement)
);

create table UtilisateurAction (
                                   idUtilisateurAction serial primary key,
                                   idUtilisateur int,
                                   idImmobilisation int,
                                   idActiondetail int,
                                   dateAction date,
                                   heureAction time,
                                   foreign key (idUtilisateur) references Utilisateur(idUtilisateur),
                                   foreign key (idImmobilisation) references Immobilisation(idImmobilisation),
                                   foreign key (idActiondetail) references ActionDetail(idActionDetail)
);


create table Ammortissement (
    idAmmortissement serial primary key,
    idImmobilisation int,
    dateUtilisation date,
    valeurbrute double precision,
    ammortissementcumuledebutperiode double precision,
    dotationdelaperiode double precision,
    ammortissementcumulefinperiode double precision,
    valeurnetcomptable double precision,
    annee int,
    foreign key (idImmobilisation) references Immobilisation(idImmobilisation)
);

CREATE VIEW VueImmobilisationAmmortissement AS
SELECT
    i.idImmobilisation,
    i.idSousCategorie,
    i.code,
    i.immobilisation,
    a.idAmmortissement,
    a.dateUtilisation,
    a.valeurbrute,
    a.ammortissementcumuledebutperiode,
    a.dotationdelaperiode,
    a.ammortissementcumulefinperiode,
    a.valeurnetcomptable,
    a.annee
FROM
    Immobilisation i
        JOIN
    Ammortissement a ON i.idImmobilisation = a.idImmobilisation;

CREATE TABLE Etat (
    idEtat serial primary key,
    Etat varchar
);
insert into etat(Etat) VALUES ('bonne etat'),
                              ('neuf(ve)'),
                               ('simba kely');

CREATE TABLE PV_Utilisation (
    idPV_Utilisation serial primary key,
    idImmobilisation int,
    idEtat int,
    datePV_Utilisation date,
    foreign key (idImmobilisation) references Immobilisation(idImmobilisation),
    foreign key (idEtat) references Etat(idEtat)
);


CREATE TABLE entreprise(
    idEntreprise serial primary key ,
    nomEntreprise varchar not null
);
insert into entreprise(nomEntreprise) VALUES ('test');

CREATE TABLE exercice(
    idExercice serial primary key,
    idEntreprise int references entreprise(idEntreprise),
    nomExercice varchar not null,
    dateDebut date not null ,
    dateFin date not null
);
insert into exercice(idEntreprise,nomExercice,dateDebut,dateFin) VALUES(1,'test','2023-01-01','2023-12-31');

CREATE VIEW vue_exercice AS
select
    exercice.*,
    entreprise.nomEntreprise
from exercice
         join entreprise on exercice.idEntreprise = entreprise.idEntreprise;

create  table taux(
    idTaux serial primary key,
    DateTaux date,
    valeur int
);


insert into taux(DateTaux,valeur) values('2023-01-01',20);

create table coefficientdegressif (
    idCoefficientdegressif serial primary key,
    dure1 int ,
    dure2 int ,
    coefficientdegressif  double precision
);
insert  into coefficientdegressif(dure1,dure2,coefficientdegressif) values(2,4,1.25),


create table typeammortissement(
    idtypeammortissement serial primary key,
    nomaamortissement varchar(40)
);

CREATE TABLE AmmortissementDegressif (
                                idAmmortissamentDegressif serial primary key,
                                idImmobilisation int,
                                dateUtilisation date,
                                base double precision,
                                tauxDegressif int,
                                tauxLineaire int ,
                                annuite double precision,
                                ValeurNetteComptable double precision,
                                Annee INT
);


