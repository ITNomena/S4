INSERT INTO Categorie (categorie) VALUES ('Materiel Informatique');
INSERT INTO Categorie (categorie) VALUES ('Mobilier transport');

INSERT INTO SousCategorie (idCategorie,sousCategorie) VALUES (1,'Ordinateur');
INSERT INTO SousCategorie (idCategorie,sousCategorie) VALUES (1,'Souris');
INSERT INTO SousCategorie (idCategorie,sousCategorie) VALUES (1,'Clavier');
INSERT INTO SousCategorie (idCategorie,sousCategorie) VALUES (1,'Tablette');
INSERT INTO SousCategorie (idCategorie,sousCategorie) VALUES (1,'Imprimente');

INSERT INTO SousCategorie (idCategorie,sousCategorie) VALUES (2,'Voiture');
INSERT INTO SousCategorie (idCategorie,sousCategorie) VALUES (2,'Moto');
INSERT INTO SousCategorie (idCategorie,sousCategorie) VALUES (2,'Bicyclette');
INSERT INTO SousCategorie (idCategorie,sousCategorie) VALUES (2,'Camion');


INSERT INTO Immobilisation (idSousCategorie, code, immobilisation) VALUES (1, 'Ord001', 'Ordinateur');(misy prix ito ahh)
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (1, 'Ord002', 'Ordinateur');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (1, 'Ord003', 'Ordinateur');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (1, 'Ord004', 'Ordinateur');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (2, 'Sour001', 'Souris');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (2, 'Sour002', 'Souris');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (2, 'Sour003', 'Souris');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (3, 'Clav001', 'Clavier');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (3, 'Clav002', 'Clavier');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (3, 'Clav003', 'Clavier');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (4, 'Tab001', 'Tablette');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (4, 'Tab002', 'Tablette');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (4, 'Tab003', 'Tablette');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (5, 'Imp001', 'Imprimente');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (5, 'Imp002', 'Imprimente');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (5, 'Imp003', 'Imprimente');
INSERT INTO Immobilisation (dSousCategorie, code, immobilisation) VALUES (5, 'Imp004', 'Imprimente');

INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (6, 'Voit001', 'Voiture');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (6, 'Voit002', 'Voiture');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (6, 'Voit003', 'Voiture');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (6, 'Voit004', 'Voiture');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (7, 'Mot001', 'Moto');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (7, 'Mot001', 'Moto');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (7, 'Mot001', 'Moto');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (8, 'Bicl002', 'Bicyclette');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (8, 'Bicl002', 'Bicyclette');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (8, 'Bicl002', 'Bicyclette');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (9, 'Cam001', 'Camion');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (9, 'Cam001', 'Camion');
INSERT INTO Immobilisation (idCategorie, code, immobilisation) VALUES (9, 'Cam001', 'Camion');


INSERT INTO Action (action) VALUES ('Utiliser');1
INSERT INTO Action (action) VALUES ('Rendre');2
INSERT INTO Action (action) VALUES ('Nettoyage');3
INSERT INTO Action (action) VALUES ('Analyse');4
INSERT INTO Action (action) VALUES ('Mise a jour');5
INSERT INTO Action (action) VALUES ('Augmentation');6
INSERT INTO Action (action) VALUES ('Reparation');7
INSERT INTO Action (action) VALUES ('Remplacement');8
INSERT INTO Action (action) VALUES ('Gonflage');9


INSERT INTO ActionDetail (idAction, detail) VALUES (1,null);
INSERT INTO ActionDetail (idAction, detail) VALUES (2,null);

--Nettoyage
INSERT INTO ActionDetail (idAction, detail) VALUES (3, 'ecran');
INSERT INTO ActionDetail (idAction, detail) VALUES (3, 'clavier');
INSERT INTO ActionDetail (idAction, detail) VALUES (3, 'vitre');
INSERT INTO ActionDetail (idAction, detail) VALUES (3, 'poussiere');
INSERT INTO ActionDetail (idAction, detail) VALUES (3, 'carosserie');
INSERT INTO ActionDetail (idAction, detail) VALUES (3, 'pneu');
INSERT INTO ActionDetail (idAction, detail) VALUES (3, 'interieur');

--Analyse
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'virus');
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'pneu');
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'volant');
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'guidon');

---mise a jour
INSERT INTO ActionDetail (idAction, detail) VALUES (5, 'vidange');
INSERT INTO ActionDetail (idAction, detail) VALUES (5, 'Systèmeexploi');
INSERT INTO ActionDetail (idAction, detail) VALUES (5, 'Logiciels ');
INSERT INTO ActionDetail (idAction, detail) VALUES (5, 'Antivirus');

--Analyse
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'Carte graphique');
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'RAM ');
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'SSD');
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'Processeur (CPU)');
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'Systèmerefroid');

--Augmentation
INSERT INTO ActionDetail (idAction, detail) VALUES (6, 'filtres à air');
INSERT INTO ActionDetail (idAction, detail) VALUES (6, 'climatisation');
INSERT INTO ActionDetail (idAction, detail) VALUES (6, 'pare-chocs avant');
INSERT INTO ActionDetail (idAction, detail) VALUES (6, 'pare-chocs arriere');

INSERT INTO ActionDetail (idAction, detail) VALUES (6, 'chaine');
INSERT INTO ActionDetail (idAction, detail) VALUES (6, 'dérailleurs');

--Repararation
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'Moteur ');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'Couleur');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'Siege');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'Volant');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'jointes');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'jantes');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'Transmission');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'plaquettes de frein');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'disques de frein');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'embrayage');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'Pneu');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'Carrosserie');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'amortisseurs');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'ressorts');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'catalyseur');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'sondes');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'fusibles');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'démarreur');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'pompe à eau');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'alternateur');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'aliment électrique');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'huile');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'pignons');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'ampoules');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'RAM');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'carte mère');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'ecran');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'pile');
INSERT INTO ActionDetail (idAction, detail) VALUES (7, 'touche');

--Remplacement
INSERT INTO ActionDetail (idAction, detail) VALUES (8, 'pneus');
INSERT INTO ActionDetail (idAction, detail) VALUES (8, 'air-bag');


--AUGMENTER
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'Carte graphique');
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'RAM ');
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'SSD');
INSERT INTO ActionDetail (idAction, detail) VALUES (4, 'Systèmerefroid');

--mise a jour
    INSERT INTO ActionDetail (idAction, detail) VALUES (5, 'encre');

    INSERT INTO ActionDetail (idAction, detail) VALUES (5, 'pile');













