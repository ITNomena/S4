create database immobilisation;

\c immobilisation;

create table categorie (
    idCategorie serial primary key,
    nom varchar(50)
);

create table article (
    idArticle serial primary key,
    nom varchar(50),
    idCategorie int not null,
    foreign key(idCategorie) references categorie(idCategorie)
);

create table service (
    idService serial primary key,
    nom varchar(50)
);

create table demande_achat (
    idDemandeAchat serial primary key,
    date date,
    idService int not null,
    idArticle int not null,
    quantite int not null,
    confirm int,
    receive int,
    foreign key(idService) references service(idService),
    foreign key(idArticle) references article(idArticle)
);

create table fournisseur (
    idFournisseur serial primary key,
    nom varchar(50),
    localisation varchar(50),
    email varchar(50),
    contact varchar(50)
);

create table proforma (
    idProforma serial primary key,
    date date,
    idFournisseur int not null,
    reference varchar(50),
    foreign key(idFournisseur) references fournisseur(idFournisseur)
);

create table detail_proforma(
    idDetailProforma serial primary key,
    idProforma int not null,
    idArticle int not null,
    quantite int not null,
    prix_unitaire double precision,
    date_livraison date,
    foreign key(idProforma) references proforma(idProforma),
    foreign key(idArticle) references article(idArticle)
);

----------------------------------------------------------------------------------------------------------

create table immobilisation (
    idImmobilisation serial primary key,
    idArticle int not null,
    code varchar(20),
    immobilisation varchar(20),
    prix double precision,
    foreign key(idArticle) references article(idArticle)
);

create table action(
    idAction serial primary key,
    action varchar(30)
);

create table actionDetail(
    idActionDetail serial primary key,
    idAction int not null,
    detail varchar(20),
    foreign key(idAction) references action(idAction)
);

create table actionImmobilisation(
    idActionImmobilisation serial primary key,
    idArticle int not null,
    idActionDetail int not null,
    foreign key(idArticle) references article(idArticle),
    foreign key(idActionDetail) references actionDetail(idActionDetail)
);

create table utilisateur (
    idUtilisateur serial primary key,
    nom varchar(50) not null,
    idService int not null,
    email varchar(50) not null,
    motdepasse varchar(50) not null,
    foreign key(idService) references service(idService)
);

create table utilisateurAction (
    idUtilisateurAction serial primary key,
    idUtilisateur int not null,
    idImmobilisation int not null,
    idActiondetail int null,
    dateAction date,
    heureAction time,
    foreign key (idUtilisateur) references utilisateur(idUtilisateur),
    foreign key (idImmobilisation) references immobilisation(idImmobilisation),
    foreign key (idActiondetail) references actionDetail(idActionDetail)
);

create table etat (
    idEtat serial primary key,
    etat varchar(50)
);

CREATE TABLE pv_reception (
    idPvReception serial primary key,
    idImmobilisation int not null,
    idEtat int not null,
    datePV_Reception date,
    annee_amortissement int,
    foreign key (idImmobilisation) references immobilisation(idImmobilisation),
    foreign key (idEtat) references etat(idEtat)
);

CREATE TABLE pv_utilisation (
    idPvUtilisation serial primary key,
    idImmobilisation int not null,
    idEtat int not null,
    datePV_Utilisation date,
    foreign key (idImmobilisation) references immobilisation(idImmobilisation),
    foreign key (idEtat) references etat(idEtat)
);

CREATE TABLE exercice(
    idExercice serial primary key,
    nomExercice varchar not null,
    dateDebut date not null ,
    dateFin date not null
);

create table coeff_degressif (
    idCoeffDegressif serial primary key,
    annee_min int,
    annee_max int,
    coefficient double precision
);

-----------------------------------------------------------------------------------------------------------

insert into categorie (nom) values ('INFORMATIQUE');
insert into categorie (nom) values ('ELECTRONIQUE');
insert into categorie (nom) values ('MOBILIER BUREAU');

insert into article (nom,idCategorie) values ('ORDINATEUR',1);
insert into article (nom,idCategorie) values ('IMPRIMANTE',1);
insert into article (nom,idCategorie) values ('APPAREIL PHOTO',2);
insert into article (nom,idCategorie) values ('CHAISE',3);
insert into article (nom,idCategorie) values ('TABLE',3);

insert into service (nom) values ('ACHAT');
insert into service (nom) values ('RH');
insert into service (nom) values ('MARKETING ET COMMUNICATION');
insert into service (nom) values ('INFORMATIQUE');

insert into immobilisation (idArticle,code,immobilisation,prix) values (1,'OR001','ORDI PORTABLE',100000);
insert into immobilisation (idArticle,code,immobilisation,prix) values (1,'OR002','ORDI PORTABLE',150000);
insert into immobilisation (idArticle,code,immobilisation,prix) values (3,'APN001','APN01',300000);

insert into action (action) values ('UTILISER');
insert into action (action) values ('RENDRE');
insert into action (action) values ('REPARATION');
insert into action (action) values ('NETTOYAGE');

insert into actionDetail (idAction,detail) values (1,null);
insert into actionDetail (idAction,detail) values (2,null);
insert into actionDetail (idAction,detail) values (3,'ECRAN');
insert into actionDetail (idAction,detail) values (3,'CLAVIER');
insert into actionDetail (idAction,detail) values (3,'RAM');
insert into actionDetail (idAction,detail) values (4,'ECRAN');
insert into actionDetail (idAction,detail) values (4,'CLAVIER');
insert into actionDetail (idAction,detail) values (4,'COMPLET');


insert into utilisateur (nom,idService,email,motdepasse) values ('MAHEFA',1,'mahrasamisoa@gmail.com','mahefa');
insert into utilisateur (nom,idService,email,motdepasse) values ('RAKOTO',1,'rakoto@gmail.com','rakoto');
insert into utilisateur (nom,idService,email,motdepasse) values ('RANDRIA',1,'randria@gmail.com','randria');

insert into utilisateurAction (idUtilisateur,idImmobilisation,idActionDetail,dateAction,heureAction) values ();

insert into etat (etat) values ('NEUF(VE)');
insert into etat (etat) values ('BONNE');

insert into exercice (nomExercice,dateDebut,dateFin) values ('EX01','2023-01-01','2023-12-31');

insert into coeff_degressif (annee_min,annee_max,coefficient) values (2,3,1.25);
insert into coeff_degressif (annee_min,annee_max,coefficient) values (4,5,1.75);
insert into coeff_degressif (annee_min,annee_max,coefficient) values (6,20,2.25);


SELECT
  idpvutilisation,
  idimmobilisation,
  idetat,
  datepv_utilisation,
  12 - EXTRACT(MONTH FROM datepv_utilisation) + 1 AS mois_restants
FROM
  pv_utilisation;

create or replace view v_plusdetail as
select utilisateur.nom,immo.code,action.action,actdet.detail,utilact.dateaction,utilact.heureaction from utilisateuraction utilact 
join utilisateur on utilisateur.idutilisateur=utilact.idutilisateur 
join immobilisation immo on immo.idimmobilisation=utilact.idimmobilisation 
join actiondetail actdet on actdet.idactiondetail=utilact.idactiondetail 
join action on action.idaction=actdet.idaction;
